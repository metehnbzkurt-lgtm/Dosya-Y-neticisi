@file:OptIn(ExperimentalMaterial3Api::class)

package com.oguzhan.dosyayoneticisi.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oguzhan.dosyayoneticisi.MainViewModel
import com.oguzhan.dosyayoneticisi.data.Cat
import com.oguzhan.dosyayoneticisi.data.Dest
import java.io.File
import kotlin.math.roundToInt

private class Tile(
    val title: String,
    val sub: String,
    val icon: ImageVector,
    val color: Color,
    val onClick: () -> Unit
)

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val dark = vm.darkMode ?: isSystemInDarkTheme()
    val st = vm.stats
    val sto = vm.storage
    val pct = (sto.fraction * 100).roundToInt()

    fun sub(c: Cat): String =
        st?.byCat?.get(c)?.let { "${formatSize(ctx, it.size)} (${it.count})" } ?: "…"

    val download = File(vm.root, "Download").path
    val baseTiles = listOf(
        Tile("Ana bellek", formatSize(ctx, sto.used), Icons.Filled.Storage, Color(0xFF6750A4)) {
            vm.push(Dest.Browse(vm.root.path))
        },
        Tile("İndirilenler", sub(Cat.DOWNLOADS), Icons.Filled.Download, Color(0xFF1E88E5)) {
            vm.push(Dest.Browse(download))
        },
        Tile("Bellek analizi", "%$pct kullanıldı", Icons.Filled.PieChart, Color(0xFF00897B)) {
            vm.push(Dest.Analysis)
        },
        Tile("Görüntüler", sub(Cat.IMAGES), Icons.Filled.Image, Color(0xFF8E24AA)) {
            vm.push(Dest.CatList(Cat.IMAGES))
        },
        Tile("Ses", sub(Cat.AUDIO), Icons.Filled.MusicNote, Color(0xFF43A047)) {
            vm.push(Dest.CatList(Cat.AUDIO))
        },
        Tile("Videolar", sub(Cat.VIDEO), Icons.Filled.Movie, Color(0xFFE53935)) {
            vm.push(Dest.CatList(Cat.VIDEO))
        },
        Tile("Belgeler", sub(Cat.DOCS), Icons.Filled.Description, Color(0xFF1E6FD9)) {
            vm.push(Dest.CatList(Cat.DOCS))
        },
        Tile(
            "Uygulamalar",
            vm.apps?.let { "${it.size} uygulama" } ?: "…",
            Icons.Filled.Apps,
            Color(0xFF2E7D32)
        ) { vm.push(Dest.Apps) },
        Tile("Yeni dosyalar", sub(Cat.NEW), Icons.Filled.Schedule, Color(0xFFEF6C00)) {
            vm.push(Dest.CatList(Cat.NEW))
        },
        Tile("Arşivler", sub(Cat.ARCHIVES), Icons.Filled.Archive, Color(0xFFF9A825)) {
            vm.push(Dest.CatList(Cat.ARCHIVES))
        },
        Tile("APK dosyaları", sub(Cat.APK), Icons.Filled.Android, Color(0xFF558B2F)) {
            vm.push(Dest.CatList(Cat.APK))
        },
        Tile("Büyük dosyalar", sub(Cat.LARGE), Icons.Filled.DataUsage, Color(0xFFD81B60)) {
            vm.push(Dest.CatList(Cat.LARGE))
        },
        Tile("Geri dönüşüm", "${vm.trashCount} öğe", Icons.Filled.RestoreFromTrash, Color(0xFF546E7A)) {
            vm.push(Dest.Trash)
        }
    )
    val extraTiles = buildList<Tile> {
        if (vm.showHistory) {
            add(Tile("Geçmiş", "${vm.history.size} dosya", Icons.Filled.History, Color(0xFF3949AB)) {
                vm.push(Dest.History)
            })
        }
        if (vm.showSystem) {
            add(Tile("Sistem", "Kök dizin", Icons.Filled.PhoneAndroid, Color(0xFF6D4C41)) {
                vm.push(Dest.Browse("/"))
            })
        }
    }
    val tiles = baseTiles + extraTiles

    BoxWithConstraints(Modifier.fillMaxSize()) {
    // Yeterince uzun ekranda kategoriler boş alanı doldurur; kısa ekranda kaydırılır
    val compact = maxHeight < 800.dp
    Column(
        (if (compact) Modifier.fillMaxSize().verticalScroll(rememberScrollState()) else Modifier.fillMaxSize())
            .padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "Merhaba, Oğuzhan",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = { vm.toggleDark(dark) },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Icon(if (dark) Icons.Filled.LightMode else Icons.Filled.DarkMode, "Tema")
                }
                IconButton(
                    onClick = { vm.push(Dest.Settings) },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Icon(Icons.Filled.Settings, "Ayarlar")
                }
            }
        }

        if (vm.usbConnected) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Filled.Usb, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                    Text(
                        "USB bağlantısı algılandı. Bilgisayarla dosya aktarmak için bildirimden \"Dosya aktarımı\" seçin.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
        }

        Surface(
            onClick = { vm.openTab(2) },
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Row(
                Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(Icons.Filled.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    "Dosya ve klasör ara…",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Küçültülmüş depolama kartı
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Depolama",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            "${formatSize(ctx, sto.used)} / ${formatSize(ctx, sto.total)} • %${pct} kullanıldı",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    if (vm.scanning) {
                        CircularProgressIndicator(
                            Modifier
                                .padding(end = 10.dp)
                                .size(18.dp),
                            strokeWidth = 2.dp
                        )
                    }
                    Button(
                        onClick = { vm.push(Dest.JunkCleaner) },
                        shape = RoundedCornerShape(99.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp),
                        modifier = Modifier.height(36.dp)
                    ) { Text("Temizle") }
                }
                LinearProgressIndicator(
                    progress = { sto.fraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(99.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.15f)
                )
            }
        }

        Text(
            "Kategoriler",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        tiles.chunked(4).forEach { row ->
            val rowMod: Modifier = if (compact) Modifier.height(112.dp) else Modifier.weight(1f)
            Row(rowMod.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { t -> TileCard(t, Modifier.weight(1f).fillMaxHeight()) }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
    }
}

@Composable
private fun TileCard(t: Tile, modifier: Modifier) {
    Card(
        onClick = t.onClick,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(t.color.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(t.icon, null, tint = t.color, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.height(6.dp))
            Text(
                t.title,
                fontSize = 13.sp,
                lineHeight = 15.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                t.sub,
                fontSize = 11.sp,
                lineHeight = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

package com.oguzhan.dosyayoneticisi

import android.app.Application
import android.content.Context
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.oguzhan.dosyayoneticisi.data.*
import com.oguzhan.dosyayoneticisi.ui.formatSize
import com.oguzhan.dosyayoneticisi.ui.sizeUnitState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    val root: File = Environment.getExternalStorageDirectory()

    // ---- gezinme
    var stack by mutableStateOf<List<Dest>>(listOf(Dest.Home))
        private set

    val currentTab: Int
        get() = when (stack.first()) {
            Dest.Home -> 0
            is Dest.Browse -> 1
            Dest.Search -> 2
            Dest.Favorites -> 3
            else -> 0
        }

    fun push(d: Dest) { stack = stack + d }

    fun pop() { if (stack.size > 1) stack = stack.dropLast(1) }

    /** Sistem geri hareketi: önce ekran yığınını geri sar, sekmedeyse Ana Sayfa'ya dön. */
    val canGoBack: Boolean get() = stack.size > 1 || currentTab != 0

    fun goBack() {
        if (stack.size > 1) pop() else if (currentTab != 0) openTab(0)
    }

    /** Ana ekran kısayolundan gelen yolu açar. */
    fun launchPath(ctx: Context, path: String) {
        val f = File(path)
        if (f.isDirectory) stack = listOf(Dest.Home, Dest.Browse(path))
        else if (f.isFile) openItem(ctx, path)
    }

    fun openTab(i: Int) {
        stack = listOf(
            when (i) {
                1 -> Dest.Browse(root.path)
                2 -> Dest.Search
                3 -> Dest.Favorites
                else -> Dest.Home
            }
        )
    }

    fun goTo(path: String) {
        val idx = stack.indexOfLast { it == Dest.Browse(path) }
        stack = if (idx >= 0) stack.take(idx + 1) else stack + Dest.Browse(path)
    }

    // ---- ayarlar
    var darkMode by mutableStateOf<Boolean?>(
        when (prefs.getInt("dark", -1)) { 0 -> false; 1 -> true; else -> null }
    )
        private set

    fun toggleDark(currentlyDark: Boolean) = setDarkMode(!currentlyDark)

    /** null = sistem temasını izle. */
    fun setDarkMode(v: Boolean?) {
        darkMode = v
        prefs.edit().putInt("dark", when (v) { null -> -1; false -> 0; true -> 1 }).apply()
    }

    var sortBy by mutableStateOf(
        runCatching { SortBy.valueOf(prefs.getString("sort", "NAME") ?: "NAME") }.getOrDefault(SortBy.NAME)
    )
        private set
    var sortAsc by mutableStateOf(prefs.getBoolean("asc", true))
        private set
    var showHidden by mutableStateOf(prefs.getBoolean("hidden", false))
        private set

    fun setSort(s: SortBy) { sortBy = s; prefs.edit().putString("sort", s.name).apply() }
    fun toggleSortOrder() { sortAsc = !sortAsc; prefs.edit().putBoolean("asc", sortAsc).apply() }
    fun toggleHidden() { showHidden = !showHidden; prefs.edit().putBoolean("hidden", showHidden).apply() }


    // ---- ek ayarlar
    private fun putB(key: String, v: Boolean) { prefs.edit().putBoolean(key, v).apply() }
    private fun putI(key: String, v: Int) { prefs.edit().putInt(key, v).apply() }

    var useTrash by mutableStateOf(prefs.getBoolean("use_trash", true))
        private set
    var confirmTrash by mutableStateOf(prefs.getBoolean("trash_confirm", true))
        private set
    var trashDays by mutableIntStateOf(prefs.getInt("trash_days", 30))
        private set
    var fullPct by mutableIntStateOf(prefs.getInt("full_pct", 98))
        private set
    var navAlways by mutableStateOf(prefs.getBoolean("nav_always", true))
        private set
    var usbDetect by mutableStateOf(prefs.getBoolean("usb_detect", true))
        private set
    var showHistory by mutableStateOf(prefs.getBoolean("show_history", true))
        private set
    var showSystem by mutableStateOf(prefs.getBoolean("show_system", false))
        private set
    var sizeUnit by mutableIntStateOf(prefs.getInt("size_unit", 0))
        private set
    var menuBookmark by mutableStateOf(prefs.getBoolean("menu_bookmark", true))
        private set
    var menuHome by mutableStateOf(prefs.getBoolean("menu_home", false))
        private set
    var menuHide by mutableStateOf(prefs.getBoolean("menu_hide", true))
        private set
    var menuOpenWith by mutableStateOf(prefs.getBoolean("menu_openwith", false))
        private set
    var builtinImage by mutableStateOf(prefs.getBoolean("builtin_img", true))
        private set
    var builtinText by mutableStateOf(prefs.getBoolean("builtin_txt", true))
        private set

    init { sizeUnitState = sizeUnit }

    fun setUseTrash(v: Boolean) { useTrash = v; putB("use_trash", v) }
    fun setConfirmTrash(v: Boolean) { confirmTrash = v; putB("trash_confirm", v) }
    fun setTrashDays(v: Int) { trashDays = v; putI("trash_days", v) }
    fun setNavAlways(v: Boolean) { navAlways = v; putB("nav_always", v) }
    fun setUsbDetect(v: Boolean) { usbDetect = v; putB("usb_detect", v); if (!v) usbConnected = false }
    fun setShowHistory(v: Boolean) { showHistory = v; putB("show_history", v) }
    fun setShowSystem(v: Boolean) { showSystem = v; putB("show_system", v) }
    fun setMenuBookmark(v: Boolean) { menuBookmark = v; putB("menu_bookmark", v) }
    fun setMenuHome(v: Boolean) { menuHome = v; putB("menu_home", v) }
    fun setMenuHide(v: Boolean) { menuHide = v; putB("menu_hide", v) }
    fun setMenuOpenWith(v: Boolean) { menuOpenWith = v; putB("menu_openwith", v) }
    fun setBuiltinImage(v: Boolean) { builtinImage = v; putB("builtin_img", v) }
    fun setBuiltinText(v: Boolean) { builtinText = v; putB("builtin_txt", v) }

    fun setSizeUnit(v: Int) {
        sizeUnit = v
        sizeUnitState = v
        putI("size_unit", v)
    }

    fun setFullPct(v: Int) {
        fullPct = v
        putI("full_pct", v)
        prefs.edit().remove("full_last").apply()
        StorageNotifier.schedule(getApplication())
        StorageNotifier.check(getApplication())
    }

    var usbConnected by mutableStateOf(false)
        private set
    fun setUsbConnected(v: Boolean) { usbConnected = v }

    // ---- varsayılan uygulamalar
    var defaultApps by mutableStateOf<Map<String, String>>(
        AppKind.values().mapNotNull { k -> prefs.getString("defapp_${k.name}", null)?.let { k.name to it } }.toMap()
    )
        private set

    fun setDefaultApp(kind: AppKind, value: String?) {
        defaultApps = if (value == null) defaultApps - kind.name else defaultApps + (kind.name to value)
        val e = prefs.edit()
        if (value == null) e.remove("defapp_${kind.name}") else e.putString("defapp_${kind.name}", value)
        e.apply()
    }

    // ---- geçmiş
    var history by mutableStateOf<List<String>>(
        (prefs.getString("history", "") ?: "").split('\n').filter { it.isNotEmpty() }
    )
        private set

    fun addHistory(path: String) {
        history = (listOf(path) + history.filter { it != path }).take(100)
        prefs.edit().putString("history", history.joinToString("\n")).apply()
    }

    fun clearHistory() {
        history = emptyList()
        prefs.edit().remove("history").apply()
    }

    /** Bir dosyayı varsayılan uygulama / dahili görüntüleyici ayarlarına göre açar. */
    fun openItem(ctx: Context, path: String) {
        val f = File(path)
        if (showHistory) addHistory(path)
        val kind = appKindOf(f.name)
        val choice = if (kind != null) defaultApps[kind.name] else null
        val internalOk = choice == null || choice == CHOICE_BUILTIN
        when {
            kind == AppKind.IMAGE && builtinImage && internalOk -> push(Dest.ImageView(path))
            kind == AppKind.TEXT && builtinText && internalOk -> push(Dest.TextEdit(path))
            choice == CHOICE_ASK -> openFileWith(ctx, f)
            choice != null && choice != CHOICE_BUILTIN -> openFile(ctx, f, choice)
            else -> openFile(ctx, f)
        }
    }

    // ---- favoriler
    var favorites by mutableStateOf<Set<String>>(prefs.getStringSet("fav", emptySet())?.toSet() ?: emptySet())
        private set

    fun toggleFavorites(paths: List<String>) {
        val allFav = paths.all { it in favorites }
        favorites = if (allFav) favorites - paths.toSet() else favorites + paths
        prefs.edit().putStringSet("fav", favorites).apply()
    }

    // ---- depolama / tarama
    var storage by mutableStateOf(readStorage(root))
        private set
    var stats by mutableStateOf<ScanResult?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    var apps by mutableStateOf<List<AppInfo>?>(null)
        private set
    var refreshTick by mutableIntStateOf(0)
        private set
    var trashCount by mutableIntStateOf(0)
        private set
    var junk by mutableStateOf<Map<JunkKind, JunkGroup>?>(null)
        private set
    var junkScanning by mutableStateOf(false)
        private set
    private var junkJob: Job? = null

    private var scanJob: Job? = null

    fun refreshStorage() { storage = readStorage(root) }

    fun refreshStats() {
        scanJob?.cancel()
        scanning = true
        scanJob = viewModelScope.launch {
            val job = coroutineContext[Job]
            val r = withContext(Dispatchers.IO) { scanStorage(root) { job?.isActive != false } }
            stats = r
            storage = readStorage(root)
            scanning = false
        }
    }

    fun loadApps() {
        viewModelScope.launch {
            apps = withContext(Dispatchers.IO) { queryApps(getApplication()) }
        }
    }

    private fun afterChange() {
        refreshTick++
        storage = readStorage(root)
        refreshStats()
        refreshTrash()
    }

    /** Uygulama açılışında bir kez çalışır. */
    fun onAppStart() {
        refreshStorage()
        refreshStats()
        loadApps()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { purgeOldTrash(root, trashDays) }
            refreshTrash()
        }
        StorageNotifier.schedule(getApplication())
        StorageNotifier.check(getApplication())
    }

    fun refreshTrash() {
        viewModelScope.launch {
            trashCount = withContext(Dispatchers.IO) { trashDir(root).list()?.size ?: 0 }
        }
    }

    fun canTrash(path: String): Boolean = canTrash(root, path)

    // ---- çöp temizleme
    fun scanJunkNow() {
        junkJob?.cancel()
        junkScanning = true
        junk = null
        junkJob = viewModelScope.launch {
            val job = coroutineContext[Job]
            val r = withContext(Dispatchers.IO) { scanJunk(getApplication(), root) { job?.isActive != false } }
            junk = r
            junkScanning = false
        }
    }

    fun cleanJunkNow(kinds: Set<JunkKind>, done: (String) -> Unit) {
        val groups = junk?.filterKeys { it in kinds }?.values?.toList() ?: return
        viewModelScope.launch {
            busy = true
            val freed = withContext(Dispatchers.IO) { cleanJunk(groups) { true } }
            busy = false
            afterChange()
            scanJunkNow()
            done("${formatSize(getApplication(), freed)} temizlendi")
        }
    }

    // ---- geri dönüşüm kutusu
    fun restoreFromTrash(entries: List<TrashEntry>, done: (String) -> Unit) {
        viewModelScope.launch {
            busy = true
            val ok = withContext(Dispatchers.IO) { entries.count { restoreEntry(it) } }
            busy = false
            afterChange()
            done("$ok öğe geri yüklendi")
        }
    }

    fun purgeFromTrash(entries: List<TrashEntry>, done: (String) -> Unit) {
        viewModelScope.launch {
            busy = true
            val ok = withContext(Dispatchers.IO) { entries.count { purgeEntry(it) } }
            busy = false
            afterChange()
            done("$ok öğe kalıcı olarak silindi")
        }
    }

    fun emptyTrashNow(done: (String) -> Unit) {
        viewModelScope.launch {
            busy = true
            withContext(Dispatchers.IO) { emptyTrash(root) }
            busy = false
            afterChange()
            done("Geri dönüşüm kutusu boşaltıldı")
        }
    }

    // ---- arama
    var searchQuery by mutableStateOf("")

    // ---- pano ve dosya işlemleri
    var clipboard by mutableStateOf<Clip?>(null)
    var busy by mutableStateOf(false)
        private set

    fun delete(paths: List<String>, permanent: Boolean = false, done: (String) -> Unit) {
        viewModelScope.launch {
            busy = true
            var trashed = 0
            var removed = 0
            withContext(Dispatchers.IO) {
                for (p in paths) {
                    val f = File(p)
                    if (useTrash && !permanent && canTrash(root, p)) {
                        if (moveToTrash(root, f)) trashed++
                    } else if (f.deleteRecursively()) {
                        removed++
                    }
                }
            }
            busy = false
            if (favorites.any { it in paths }) {
                favorites = favorites - paths.toSet()
                prefs.edit().putStringSet("fav", favorites).apply()
            }
            afterChange()
            done(
                when {
                    trashed > 0 && removed == 0 -> "$trashed öğe geri dönüşüm kutusuna taşındı"
                    trashed == 0 -> "$removed öğe silindi"
                    else -> "${trashed + removed} öğe silindi"
                }
            )
        }
    }

    /** Gizle / Göster: ada nokta ekler veya kaldırır. */
    fun toggleHide(paths: List<String>, done: (String) -> Unit) {
        viewModelScope.launch {
            val allHidden = paths.all { File(it).name.startsWith(".") }
            val ok = withContext(Dispatchers.IO) {
                paths.count { p ->
                    val f = File(p)
                    val newName = if (allHidden) f.name.trimStart('.') else if (f.name.startsWith(".")) null else "." + f.name
                    if (newName.isNullOrEmpty()) false else {
                        val t = File(f.parentFile, newName)
                        !t.exists() && f.renameTo(t)
                    }
                }
            }
            favorites = favorites - paths.toSet()
            prefs.edit().putStringSet("fav", favorites).apply()
            afterChange()
            done(if (allHidden) "$ok öğe gösterildi" else "$ok öğe gizlendi")
        }
    }

    fun paste(dir: String, done: (String) -> Unit) {
        val c = clipboard ?: return
        viewModelScope.launch {
            busy = true
            val ok = withContext(Dispatchers.IO) {
                var n = 0
                val dest = File(dir)
                for (p in c.paths) {
                    val src = File(p)
                    if (!src.exists()) continue
                    if (src.isDirectory && isInside(dest, src)) continue
                    if (c.cut && src.parentFile?.path == dir) continue
                    try {
                        val target = uniqueTarget(dest, src.name)
                        if (c.cut) moveItem(src, target) else copyItem(src, target)
                        n++
                    } catch (e: Exception) {
                        // bu öğe atlanır
                    }
                }
                n
            }
            busy = false
            if (c.cut) clipboard = null
            afterChange()
            done("$ok öğe ${if (c.cut) "taşındı" else "kopyalandı"}")
        }
    }

    fun rename(path: String, newName: String, done: (String) -> Unit) {
        val name = newName.trim()
        if (name.isEmpty() || name.contains('/')) {
            done("Geçersiz ad")
            return
        }
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                val f = File(path)
                val t = File(f.parentFile, name)
                !t.exists() && f.renameTo(t)
            }
            afterChange()
            done(if (ok) "Yeniden adlandırıldı" else "Bu adda bir öğe var veya işlem başarısız")
        }
    }

    fun newFolder(parent: String, name: String, done: (String) -> Unit) {
        val n = name.trim()
        if (n.isEmpty() || n.contains('/')) {
            done("Geçersiz ad")
            return
        }
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                val t = File(parent, n)
                !t.exists() && t.mkdirs()
            }
            afterChange()
            done(if (ok) "Klasör oluşturuldu" else "Klasör oluşturulamadı")
        }
    }
}

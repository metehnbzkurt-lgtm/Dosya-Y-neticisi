package com.oguzhan.dosyayoneticisi.data

import java.io.File

/**
 * Geri dönüşüm kutusu. Silinen her öğe, ana bellekteki gizli bir klasörde
 * <kutu>/<id>/item/<ad> olarak saklanır; özgün konumu <kutu>/<id>/meta dosyasındadır.
 * Klasör nokta ile başladığı için tarama ve kategori listelerinde görünmez.
 */
const val TRASH_DIR_NAME = ".DosyaYoneticisi_Cop"

fun trashDir(root: File): File = File(root, TRASH_DIR_NAME)

fun isInTrash(root: File, path: String): Boolean =
    path.startsWith(trashDir(root).path + "/")

/** Yalnızca ana bellek içindeki (ve kutunun kendisinde olmayan) öğeler kutuya taşınabilir. */
fun canTrash(root: File, path: String): Boolean =
    path.startsWith(root.path + "/") && !isInTrash(root, path)

fun sizeOfTree(f: File): Long =
    if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

fun moveToTrash(root: File, src: File): Boolean {
    val entry = File(trashDir(root), "${System.currentTimeMillis()}_${(1000..9999).random()}")
    return try {
        val itemDir = File(entry, "item")
        if (!itemDir.mkdirs()) return false
        moveItem(src, File(itemDir, src.name))
        File(entry, "meta").writeText(src.path + "\n" + System.currentTimeMillis())
        true
    } catch (e: Exception) {
        entry.deleteRecursively()
        false
    }
}

fun listTrash(root: File): List<TrashEntry> {
    val dirs = trashDir(root).listFiles() ?: return emptyList()
    return dirs.mapNotNull { e ->
        try {
            val meta = File(e, "meta").takeIf { it.exists() }?.readLines() ?: return@mapNotNull null
            val orig = meta.getOrNull(0) ?: return@mapNotNull null
            val item = File(e, "item").listFiles()?.firstOrNull() ?: return@mapNotNull null
            TrashEntry(
                id = e.name,
                name = item.name,
                isDir = item.isDirectory,
                size = sizeOfTree(item),
                deletedAt = meta.getOrNull(1)?.toLongOrNull() ?: e.lastModified(),
                origPath = orig,
                itemPath = item.path
            )
        } catch (x: Exception) {
            null
        }
    }.sortedByDescending { it.deletedAt }
}

private fun entryDir(entry: TrashEntry): File? = File(entry.itemPath).parentFile?.parentFile

fun restoreEntry(entry: TrashEntry): Boolean = try {
    val parent = File(entry.origPath).parentFile
    if (parent == null) {
        false
    } else {
        parent.mkdirs()
        moveItem(File(entry.itemPath), uniqueTarget(parent, entry.name))
        entryDir(entry)?.deleteRecursively()
        true
    }
} catch (e: Exception) {
    false
}

fun purgeEntry(entry: TrashEntry): Boolean = entryDir(entry)?.deleteRecursively() ?: false

fun emptyTrash(root: File) { trashDir(root).deleteRecursively() }

/** [days] günden eski öğeleri kalıcı olarak siler. */
fun purgeOldTrash(root: File, days: Int) {
    if (days <= 0) return
    val limit = System.currentTimeMillis() - days * 24L * 60 * 60 * 1000
    listTrash(root).filter { it.deletedAt < limit }.forEach { purgeEntry(it) }
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.oguzhan.dosyayoneticisi.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oguzhan.dosyayoneticisi.MainViewModel
import com.oguzhan.dosyayoneticisi.data.JunkKind

private val Teal = Color(0xFF00D4AB)

private fun junkIcon(k: JunkKind): Pair<ImageVector, Color> = when (k) {
    JunkKind.SYSTEM -> Icons.Filled.Delete to Color(0xFFFF8A3D)
    JunkKind.CACHE -> Icons.Filled.CleaningServices to Color(0xFF3B82F6)
    JunkKind.UNUSED -> Icons.Filled.Widgets to Color(0xFFF0547A)
    JunkKind.APKS -> Icons.Filled.Android to Color(0xFF3DB35A)
}

@Composable
fun JunkScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val junk = vm.junk
    val scanning = vm.junkScanning
    var checked by remember { mutableStateOf(setOf<JunkKind>()) }
    var confirm by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.scanJunkNow() }
    // Tarama bitince APK dışındaki bulunan gruplar önceden seçilir
    LaunchedEffect(junk) {
        checked = junk?.filter { it.key != JunkKind.APKS && it.value.paths.isNotEmpty() }?.keys.orEmpty()
    }

    val selectedCount = junk?.filterKeys { it in checked }?.values?.sumOf { it.paths.size } ?: 0
    val total = junk?.values?.sumOf { it.size } ?: 0L
    val parts = formatSize(ctx, total).split(Regex("[\\s\\u00A0]+"))
    val number = parts.firstOrNull().orEmpty()
    val unit = parts.drop(1).joinToString(" ")
    val statusBarTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    Column(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(240.dp)
                .background(Teal)
        ) {
            // Üst durum çubuğu alanını da aynı renge boya
            Box(
                Modifier
                    .offset(y = -statusBarTop)
                    .fillMaxWidth()
                    .height(statusBarTop)
                    .background(Teal)
            )
            IconButton(onClick = { vm.pop() }, modifier = Modifier.align(Alignment.TopStart).padding(4.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White)
            }
            if (scanning) {
                CircularProgressIndicator(
                    Modifier.align(Alignment.TopEnd).padding(16.dp).size(24.dp),
                    color = Color.White,
                    strokeWidth = 2.dp
                )
            }
            Column(Modifier.align(Alignment.BottomStart).padding(start = 16.dp, bottom = 16.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(number.ifEmpty { "0" }, fontSize = 64.sp, color = Color.White, fontWeight = FontWeight.Light)
                    Text(
                        unit.ifEmpty { "B" },
                        Modifier.padding(start = 4.dp, bottom = 14.dp),
                        fontSize = 16.sp,
                        color = Color.White
                    )
                }
                Text(
                    if (scanning) "Taranıyor…" else "Tarama tamamlandı",
                    color = Color.White.copy(alpha = 0.9f),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())

        Surface(color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxWidth()) {
                JunkKind.values().forEach { k ->
                    val g = junk?.get(k)
                    val has = g != null && g.paths.isNotEmpty()
                    val isOn = k in checked
                    val (icon, color) = junkIcon(k)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable(enabled = has) {
                                checked = if (isOn) checked - k else checked + k
                            }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).background(color),
                            contentAlignment = Alignment.Center
                        ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
                        Text(k.title, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                        Text(
                            when {
                                g == null -> "…"
                                g.size == 0L && g.paths.isNotEmpty() -> "${g.paths.size} öğe"
                                else -> formatSize(ctx, g.size)
                            },
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Box(
                            Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .then(
                                    if (isOn) Modifier.background(Teal)
                                    else Modifier.border(1.5.dp, MaterialTheme.colorScheme.outline, CircleShape)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isOn) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        Text(
            "Not: Android 11 ve üstünde diğer uygulamaların önbelleği sistem tarafından kapatıldığı için taranamaz.",
            Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.weight(1f))

        Button(
            onClick = { confirm = true },
            enabled = selectedCount > 0 && !vm.busy,
            shape = RoundedCornerShape(99.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Teal, contentColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .height(56.dp)
        ) { Text("Çöpleri temizle", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Çöpler temizlensin mi?") },
            text = {
                Text(
                    "Seçili kategorilerdeki $selectedCount öğe kalıcı olarak silinecek " +
                        "(geri dönüşüm kutusuna taşınmaz)."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    vm.cleanJunkNow(checked) { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() }
                }) { Text("Temizle") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Vazgeç") } }
        )
    }
}

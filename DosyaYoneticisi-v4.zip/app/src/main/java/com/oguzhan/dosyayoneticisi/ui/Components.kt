@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.oguzhan.dosyayoneticisi.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.os.Build
import android.provider.MediaStore
import android.text.format.Formatter
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.oguzhan.dosyayoneticisi.data.Cat
import com.oguzhan.dosyayoneticisi.data.FileItem
import com.oguzhan.dosyayoneticisi.data.typeOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val NoInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp)

@Composable
fun barColors() = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)

private val dateFmt = SimpleDateFormat("d MMM yyyy", Locale("tr", "TR"))

fun formatDate(ms: Long): String = dateFmt.format(Date(ms))

/** 0 = otomatik, 1 = KB, 2 = MB, 3 = GB. Compose durumu olduğu için değişince ekranlar yenilenir. */
var sizeUnitState by mutableIntStateOf(0)

fun formatSize(ctx: Context, bytes: Long): String {
    val (div, unit, fmt) = when (sizeUnitState) {
        1 -> Triple(1024.0, "KB", "%.0f")
        2 -> Triple(1024.0 * 1024, "MB", "%.1f")
        3 -> Triple(1024.0 * 1024 * 1024, "GB", "%.2f")
        else -> return Formatter.formatFileSize(ctx, bytes)
    }
    return String.format(Locale.getDefault(), "$fmt $unit", bytes / div)
}

fun iconFor(item: FileItem): Pair<ImageVector, Color> {
    if (item.isDir) return Icons.Filled.Folder to Color(0xFFF9A825)
    return when (typeOf(item.name)) {
        Cat.IMAGES -> Icons.Filled.Image to Color(0xFF8E24AA)
        Cat.VIDEO -> Icons.Filled.Movie to Color(0xFFE53935)
        Cat.AUDIO -> Icons.Filled.MusicNote to Color(0xFF43A047)
        Cat.DOCS -> Icons.Filled.Description to Color(0xFF1E6FD9)
        Cat.ARCHIVES -> Icons.Filled.Archive to Color(0xFFF9A825)
        Cat.APK -> Icons.Filled.Android to Color(0xFF2E7D32)
        else -> Icons.Filled.InsertDriveFile to Color(0xFF78909C)
    }
}

// ------------------------------------------------------------------ küçük resimler

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun peek(path: String): Bitmap? = cache.get(path)

    suspend fun load(path: String, video: Boolean, px: Int): Bitmap? = withContext(Dispatchers.IO) {
        cache.get(path) ?: decode(path, video, px)?.also { cache.put(path, it) }
    }

    @Suppress("DEPRECATION")
    private fun decode(path: String, video: Boolean, px: Int): Bitmap? = try {
        if (video) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ThumbnailUtils.createVideoThumbnail(File(path), Size(px, px), null)
            } else {
                ThumbnailUtils.createVideoThumbnail(path, MediaStore.Video.Thumbnails.MINI_KIND)
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                null
            } else {
                var s = 1
                while (bounds.outWidth / (s * 2) >= px && bounds.outHeight / (s * 2) >= px) s *= 2
                BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
            }
        }
    } catch (e: Throwable) {
        null
    }
}

@Composable
fun FileThumb(item: FileItem) {
    val type = remember(item.name, item.isDir) { if (item.isDir) null else typeOf(item.name) }
    val (icon, color) = remember(item.path) { iconFor(item) }
    val canThumb = type == Cat.IMAGES || type == Cat.VIDEO
    val bmp by produceState<Bitmap?>(
        initialValue = if (canThumb) Thumbs.peek(item.path) else null,
        item.path,
        item.modified
    ) {
        if (canThumb && value == null) value = Thumbs.load(item.path, type == Cat.VIDEO, 128)
    }
    Box(
        Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(icon, null, tint = color)
        }
    }
}

// ------------------------------------------------------------------ satır

@Composable
fun FileRow(
    item: FileItem,
    selected: Boolean,
    favorite: Boolean,
    showParent: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val ctx = LocalContext.current
    val unit = sizeUnitState
    val sub = remember(item.path, item.modified, item.size, showParent, unit) {
        buildString {
            if (item.isDir) append("${item.childCount} öğe") else append(formatSize(ctx, item.size))
            append(" • ")
            append(formatDate(item.modified))
            if (showParent) {
                append(" • ")
                append(File(item.path).parentFile?.name.orEmpty())
            }
        }
    }
    val bg = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
    Row(
        Modifier
            .fillMaxWidth()
            .background(bg)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
            if (selected) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Check, null, tint = MaterialTheme.colorScheme.onPrimary)
                }
            } else {
                FileThumb(item)
            }
        }
        Column(Modifier.weight(1f)) {
            Text(
                item.name,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                sub,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (favorite) {
            Icon(
                Icons.Filled.Favorite,
                null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

// ------------------------------------------------------------------ uygulama simgesi

@Composable
fun AppIcon(pkg: String) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, pkg) {
        value = withContext(Dispatchers.IO) {
            try {
                ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96)
            } catch (e: Exception) {
                null
            }
        }
    }
    Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize())
        } else {
            Icon(Icons.Filled.Android, null, tint = Color(0xFF2E7D32))
        }
    }
}

// ------------------------------------------------------------------ diyalog

@Composable
fun TextInputDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } }
    )
}

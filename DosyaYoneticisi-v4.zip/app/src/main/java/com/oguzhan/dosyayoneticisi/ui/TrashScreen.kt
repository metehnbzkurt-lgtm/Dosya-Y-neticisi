@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.oguzhan.dosyayoneticisi.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.oguzhan.dosyayoneticisi.MainViewModel
import com.oguzhan.dosyayoneticisi.data.FileItem
import com.oguzhan.dosyayoneticisi.data.TrashEntry
import com.oguzhan.dosyayoneticisi.data.listTrash
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun TrashScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var entries by remember { mutableStateOf<List<TrashEntry>?>(null) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var detail by remember { mutableStateOf<TrashEntry?>(null) }
    var purge by remember { mutableStateOf<List<TrashEntry>?>(null) }
    var confirmEmpty by remember { mutableStateOf(false) }
    val selecting = selected.isNotEmpty()

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    LaunchedEffect(vm.refreshTick) {
        val list = withContext(Dispatchers.IO) { listTrash(vm.root) }
        entries = list
        val ids = list.map { it.id }.toSet()
        selected = selected.filter { it in ids }.toSet()
    }

    BackHandler(enabled = selecting) { selected = emptySet() }

    val list = entries

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (selecting) {
                TopAppBar(
                    title = { Text("${selected.size} seçili") },
                    navigationIcon = {
                        IconButton(onClick = { selected = emptySet() }) { Icon(Icons.Filled.Close, "Seçimi kapat") }
                    },
                    actions = {
                        IconButton(onClick = { selected = list.orEmpty().map { it.id }.toSet() }) {
                            Icon(Icons.Filled.SelectAll, "Tümünü seç")
                        }
                    },
                    windowInsets = NoInsets,
                    colors = barColors()
                )
            } else {
                SimpleBar("Geri dönüşüm kutusu", { vm.pop() }) {
                    if (!list.isNullOrEmpty()) {
                        IconButton(onClick = { confirmEmpty = true }) {
                            Icon(Icons.Filled.DeleteForever, "Kutuyu boşalt")
                        }
                    }
                }
            }
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (vm.trashDays > 0) {
                Text(
                    "Öğeler ${vm.trashDays} gün sonra otomatik olarak kalıcı silinir",
                    Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            when {
                list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                list.isEmpty() -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Geri dönüşüm kutusu boş",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
                else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 96.dp)) {
                    items(list, key = { it.id }) { e ->
                        val sel = e.id in selected
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(if (sel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                .combinedClickable(
                                    onClick = {
                                        if (selecting) selected = if (sel) selected - e.id else selected + e.id
                                        else detail = e
                                    },
                                    onLongClick = { selected = if (sel) selected - e.id else selected + e.id }
                                )
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                                if (sel) {
                                    Box(
                                        Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primary),
                                        contentAlignment = Alignment.Center
                                    ) { Icon(Icons.Filled.Check, null, tint = MaterialTheme.colorScheme.onPrimary) }
                                } else {
                                    FileThumb(FileItem(e.itemPath, e.name, e.isDir, e.size, e.deletedAt))
                                }
                            }
                            Column(Modifier.weight(1f)) {
                                Text(
                                    e.name,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Text(
                                    "${formatSize(ctx, e.size)} • ${formatDate(e.deletedAt)} • ${File(e.origPath).parentFile?.name.orEmpty()}",
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        if (selecting) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(12.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                tonalElevation = 6.dp,
                shadowElevation = 6.dp
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    BarAction(Icons.Filled.RestoreFromTrash, "Geri yükle") {
                        val chosen = list.orEmpty().filter { it.id in selected }
                        selected = emptySet()
                        vm.restoreFromTrash(chosen) { toast(it) }
                    }
                    BarAction(Icons.Filled.DeleteForever, "Kalıcı sil") {
                        purge = list.orEmpty().filter { it.id in selected }
                    }
                }
            }
        }
    }

    val d = detail
    if (d != null) {
        AlertDialog(
            onDismissRequest = { detail = null },
            title = { Text(d.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = {
                Text(
                    "Özgün konum:\n${File(d.origPath).parent.orEmpty()}\n\n" +
                        "Boyut: ${formatSize(ctx, d.size)}\nSilinme: ${formatDate(d.deletedAt)}"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    detail = null
                    vm.restoreFromTrash(listOf(d)) { toast(it) }
                }) { Text("Geri yükle") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { detail = null; purge = listOf(d) }) { Text("Kalıcı sil") }
                    TextButton(onClick = { detail = null }) { Text("Kapat") }
                }
            }
        )
    }

    val p = purge
    if (p != null) {
        AlertDialog(
            onDismissRequest = { purge = null },
            title = { Text("Kalıcı olarak silinsin mi?") },
            text = { Text("${p.size} öğe kalıcı olarak silinecek. Bu işlem geri alınamaz.") },
            confirmButton = {
                TextButton(onClick = {
                    purge = null
                    selected = emptySet()
                    vm.purgeFromTrash(p) { toast(it) }
                }) { Text("Sil") }
            },
            dismissButton = { TextButton(onClick = { purge = null }) { Text("Vazgeç") } }
        )
    }

    if (confirmEmpty) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            title = { Text("Kutu boşaltılsın mı?") },
            text = { Text("Geri dönüşüm kutusundaki tüm öğeler kalıcı olarak silinecek.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmEmpty = false
                    vm.emptyTrashNow { toast(it) }
                }) { Text("Boşalt") }
            },
            dismissButton = { TextButton(onClick = { confirmEmpty = false }) { Text("Vazgeç") } }
        )
    }
}

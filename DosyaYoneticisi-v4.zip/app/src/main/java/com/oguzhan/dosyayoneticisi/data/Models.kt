package com.oguzhan.dosyayoneticisi.data

enum class Cat(val title: String) {
    IMAGES("Görüntüler"),
    VIDEO("Videolar"),
    AUDIO("Ses"),
    DOCS("Belgeler"),
    ARCHIVES("Arşivler"),
    APK("APK dosyaları"),
    DOWNLOADS("İndirilenler"),
    NEW("Yeni dosyalar"),
    LARGE("Büyük dosyalar")
}

enum class SortBy { NAME, DATE, SIZE }

data class FileItem(
    val path: String,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val childCount: Int = -1
)

data class CatStat(val count: Int = 0, val size: Long = 0L)

data class ScanResult(val byCat: Map<Cat, CatStat>, val filesSize: Long, val fileCount: Int)

data class StorageInfo(val total: Long, val used: Long) {
    val fraction: Float get() = if (total > 0) (used.toFloat() / total).coerceIn(0f, 1f) else 0f
    val free: Long get() = (total - used).coerceAtLeast(0L)
}

data class AppInfo(val label: String, val pkg: String, val size: Long)

data class Clip(val paths: List<String>, val cut: Boolean)

sealed interface Dest {
    object Home : Dest
    data class Browse(val path: String) : Dest
    data class CatList(val cat: Cat) : Dest
    object Analysis : Dest
    object Apps : Dest
    object Search : Dest
    object Favorites : Dest
    object Settings : Dest
    object JunkCleaner : Dest
    object Trash : Dest
    object History : Dest
    object DefaultApps : Dest
    object BuiltinApps : Dest
    data class ImageView(val path: String) : Dest
    data class TextEdit(val path: String) : Dest
}

/** Geri dönüşüm kutusundaki bir öğe. */
data class TrashEntry(
    val id: String,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val deletedAt: Long,
    val origPath: String,
    val itemPath: String
)

/** Geçici dosya (çöp) tarama kategorileri. */
enum class JunkKind(val title: String) {
    SYSTEM("Sistem Çöpleri"),
    CACHE("Önbellek verileri"),
    UNUSED("Kullanılmayan verileri kaldır"),
    APKS("Gereksiz kurulum paketi")
}

data class JunkGroup(val paths: List<String>, val size: Long)

/** Varsayılan uygulama seçilebilen dosya türleri. */
enum class AppKind(val title: String, val mime: String, val hasBuiltin: Boolean) {
    IMAGE("Görüntüler", "image/*", true),
    VIDEO("Videolar", "video/*", false),
    AUDIO("Ses", "audio/*", false),
    PDF("PDF belgeleri", "application/pdf", false),
    TEXT("Metin dosyaları", "text/plain", true)
}

const val CHOICE_BUILTIN = "builtin"
const val CHOICE_ASK = "ask"

package com.oguzhan.dosyayoneticisi

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import com.oguzhan.dosyayoneticisi.data.readStorage
import java.util.concurrent.TimeUnit

/** "Bellek dolu" bildirimi: depolama, ayarlardaki yüzdeye ulaşınca (günde en fazla bir kez) gösterilir. */
object StorageNotifier {
    private const val CHANNEL = "storage_full"
    private const val WORK = "storage_check"
    private const val DAY = 24L * 60 * 60 * 1000

    fun check(ctx: Context) {
        val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val threshold = prefs.getInt("full_pct", 98)
        if (threshold <= 0) return
        val s = readStorage(Environment.getExternalStorageDirectory())
        if (s.total <= 0) return
        val pct = (s.fraction * 100).toInt()
        if (pct < threshold) return
        val now = System.currentTimeMillis()
        if (now - prefs.getLong("full_last", 0L) < DAY) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Bellek dolu", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Bellek dolu")
            .setContentText("Depolama alanı %$pct dolu. Yer açmak için dokunun.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(1001, n)
            prefs.edit().putLong("full_last", now).apply()
        } catch (e: SecurityException) {
            // bildirim izni yok
        }
    }

    /** Eşik açıksa 6 saatte bir kontrol eden işi planlar; kapalıysa iptal eder. */
    fun schedule(ctx: Context) {
        val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val wm = WorkManager.getInstance(ctx)
        if (prefs.getInt("full_pct", 98) > 0) {
            wm.enqueueUniquePeriodicWork(
                WORK,
                ExistingPeriodicWorkPolicy.UPDATE,
                PeriodicWorkRequest.Builder(StorageWorker::class.java, 6, TimeUnit.HOURS).build()
            )
        } else {
            wm.cancelUniqueWork(WORK)
        }
    }
}

class StorageWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        StorageNotifier.check(applicationContext)
        return Result.success()
    }
}

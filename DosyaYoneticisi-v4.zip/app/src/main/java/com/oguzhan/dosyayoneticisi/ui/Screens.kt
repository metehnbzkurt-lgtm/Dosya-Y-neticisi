@file:OptIn(ExperimentalMaterial3Api::class)

package com.oguzhan.dosyayoneticisi.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.oguzhan.dosyayoneticisi.MainViewModel
import com.oguzhan.dosyayoneticisi.data.Cat
import com.oguzhan.dosyayoneticisi.data.FileItem
import com.oguzhan.dosyayoneticisi.data.listCategory
import com.oguzhan.dosyayoneticisi.data.listDir
import com.oguzhan.dosyayoneticisi.data.openAppSettings
import com.oguzhan.dosyayoneticisi.data.searchFiles
import com.oguzhan.dosyayoneticisi.data.toItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

// ------------------------------------------------------------------ klasör gezgini

@Composable
fun BrowseScreen(vm: MainViewModel, path: String) {
    val ctx = LocalContext.current
    var items by remember { mutableStateOf<List<FileItem>?>(null) }
    var showNew by remember { mutableStateOf(false) }

    LaunchedEffect(path, vm.refreshTick, vm.sortBy, vm.sortAsc, vm.showHidden) {
        val sort = vm.sortBy
        val asc = vm.sortAsc
        val hidden = vm.showHidden
        items = withContext(Dispatchers.IO) { listDir(File(path), sort, asc, hidden) }
    }

    // "/" altında gezilirken (Sistem depolaması) kök "/" olur
    val rootPath = if (path == "/" || !path.startsWith(vm.root.path)) "/" else vm.root.path
    val rootLabel = if (rootPath == "/") "Sistem" else "Ana bellek"
    val title = if (path == rootPath) rootLabel else File(path).name

    FileScreen(
        vm = vm,
        title = title,
        items = items,
        emptyText = "Bu klasör boş",
        onBack = if (vm.stack.size > 1) ({ vm.pop() }) else null,
        pasteDir = path,
        topActions = {
            IconButton(onClick = { showNew = true }) { Icon(Icons.Filled.CreateNewFolder, "Yeni klasör") }
            SortMenu(vm)
        },
        belowBar = {
            val rel = path.removePrefix(rootPath).trim('/')
            val segs = if (rel.isEmpty()) emptyList() else rel.split('/')
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Crumb(rootLabel, segs.isEmpty()) { vm.goTo(rootPath) }
                segs.forEachIndexed { i, s ->
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        null,
                        Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Crumb(s, i == segs.lastIndex) {
                        vm.goTo(File(rootPath, segs.take(i + 1).joinToString("/")).path)
                    }
                }
            }
        }
    )

    if (showNew) {
        TextInputDialog(
            title = "Yeni klasör",
            initial = "",
            confirmLabel = "Oluştur",
            onDismiss = { showNew = false },
            onConfirm = { name ->
                showNew = false
                vm.newFolder(path, name) { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() }
            }
        )
    }
}

@Composable
private fun Crumb(text: String, current: Boolean, onClick: () -> Unit) {
    Text(
        text,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        style = MaterialTheme.typography.labelLarge,
        fontWeight = if (current) FontWeight.Bold else FontWeight.Normal,
        color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1
    )
}

// ------------------------------------------------------------------ kategori listesi

@Composable
fun CategoryScreen(vm: MainViewModel, cat: Cat) {
    var items by remember { mutableStateOf<List<FileItem>?>(null) }

    LaunchedEffect(cat, vm.refreshTick) {
        items = withContext(Dispatchers.IO) {
            val job = currentCoroutineContext()[Job]
            listCategory(vm.root, cat) { job?.isActive != false }
        }
    }

    FileScreen(
        vm = vm,
        title = cat.title,
        items = items,
        emptyText = "Bu kategoride dosya bulunamadı",
        onBack = { vm.pop() },
        showParent = true,
        belowBar = {
            if (cat == Cat.LARGE) {
                Text(
                    "100 MB ve üzeri dosyalar • Silmek için uzun basarak seçin",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    )
}

// ------------------------------------------------------------------ arama

@Composable
fun SearchScreen(vm: MainViewModel) {
    var items by remember { mutableStateOf<List<FileItem>?>(emptyList()) }
    val focus = remember { FocusRequester() }
    val q = vm.searchQuery.trim()

    LaunchedEffect(Unit) { if (vm.searchQuery.isEmpty()) focus.requestFocus() }

    LaunchedEffect(q, vm.refreshTick) {
        if (q.length < 2) {
            items = emptyList()
        } else {
            delay(300)
            items = null
            items = withContext(Dispatchers.IO) {
                val job = currentCoroutineContext()[Job]
                searchFiles(vm.root, q, 300) { job?.isActive != false }
            }
        }
    }

    FileScreen(
        vm = vm,
        title = "Ara",
        items = items,
        emptyText = if (q.length < 2) "Aramak için en az 2 karakter yazın" else "Sonuç bulunamadı",
        onBack = null,
        showParent = true,
        belowBar = {
            OutlinedTextField(
                value = vm.searchQuery,
                onValueChange = { vm.searchQuery = it },
                placeholder = { Text("Dosya ve klasör adı") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (vm.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { vm.searchQuery = "" }) { Icon(Icons.Filled.Close, "Temizle") }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .focusRequester(focus)
            )
        }
    )
}

// ------------------------------------------------------------------ favoriler

@Composable
fun FavoritesScreen(vm: MainViewModel) {
    var items by remember { mutableStateOf<List<FileItem>?>(null) }
    LaunchedEffect(vm.favorites, vm.refreshTick) {
        val favs = vm.favorites
        items = withContext(Dispatchers.IO) {
            favs.map { File(it) }
                .filter { it.exists() }
                .map { toItem(it) }
                .sortedWith(compareBy<FileItem>({ !it.isDir }, { it.name.lowercase() }))
        }
    }
    FileScreen(
        vm = vm,
        title = "Favoriler",
        items = items,
        emptyText = "Henüz favori yok.\nBir dosyaya uzun basıp Diğer > Favorilere ekle'yi seçin.",
        onBack = null,
        showParent = true
    )
}

// ------------------------------------------------------------------ uygulamalar

@Composable
fun AppsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val apps = vm.apps
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Uygulamalar") },
            navigationIcon = {
                IconButton(onClick = { vm.pop() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") }
            },
            windowInsets = NoInsets,
            colors = barColors()
        )
        if (apps == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            Text(
                "${apps.size} uygulama • APK toplamı ${formatSize(ctx, apps.sumOf { it.size })}",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            LazyColumn(Modifier.fillMaxSize()) {
                items(apps, key = { it.pkg }) { a ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { openAppSettings(ctx, a.pkg) }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        AppIcon(a.pkg)
                        Column(Modifier.weight(1f)) {
                            Text(
                                a.label,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                a.pkg,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            formatSize(ctx, a.size),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ bellek analizi

private class Seg(val label: String, val bytes: Long, val color: Color)

@Composable
fun AnalysisScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val sto = vm.storage
    val st = vm.stats
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Bellek analizi") },
            navigationIcon = {
                IconButton(onClick = { vm.pop() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") }
            },
            windowInsets = NoInsets,
            colors = barColors()
        )
        if (st == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            fun size(c: Cat): Long = st.byCat[c]?.size ?: 0L
            val typed = listOf(Cat.IMAGES, Cat.VIDEO, Cat.AUDIO, Cat.DOCS, Cat.ARCHIVES, Cat.APK)
                .sumOf { size(it) }
            val other = (st.filesSize - typed).coerceAtLeast(0L)
            val system = (sto.used - st.filesSize).coerceAtLeast(0L)
            val segs = listOf(
                Seg("Görüntüler", size(Cat.IMAGES), Color(0xFF8E24AA)),
                Seg("Videolar", size(Cat.VIDEO), Color(0xFFE53935)),
                Seg("Ses", size(Cat.AUDIO), Color(0xFF43A047)),
                Seg("Belgeler", size(Cat.DOCS), Color(0xFF1E6FD9)),
                Seg("Arşivler", size(Cat.ARCHIVES), Color(0xFFF9A825)),
                Seg("APK dosyaları", size(Cat.APK), Color(0xFF558B2F)),
                Seg("Diğer dosyalar", other, Color(0xFF78909C)),
                Seg("Sistem ve uygulamalar", system, Color(0xFF6750A4)),
                Seg("Boş alan", sto.free, MaterialTheme.colorScheme.surfaceVariant)
            )
            val total = if (sto.total > 0) sto.total else 1L

            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    "${formatSize(ctx, sto.used)} / ${formatSize(ctx, sto.total)} kullanıldı",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(16.dp)
                        .clip(RoundedCornerShape(99.dp))
                ) {
                    segs.filter { it.bytes > 0 }.forEach {
                        Box(
                            Modifier
                                .weight(it.bytes.toFloat())
                                .fillMaxHeight()
                                .background(it.color)
                        )
                    }
                }
                segs.forEach { s ->
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(s.color)
                        )
                        Text(s.label, Modifier.weight(1f))
                        Text(
                            formatSize(ctx, s.bytes),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "%${(s.bytes * 100f / total).roundToInt()}",
                            Modifier.padding(start = 4.dp),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

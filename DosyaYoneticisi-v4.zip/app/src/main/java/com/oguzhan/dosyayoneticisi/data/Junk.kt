package com.oguzhan.dosyayoneticisi.data

import android.content.Context
import android.os.Build
import java.io.File

private val JUNK_EXT = setOf("tmp", "temp", "log", "bak", "old", "chk", "dmp", "crdownload", "part")
private val JUNK_DIRS = setOf(".thumbnails", "LOST.DIR", ".cache", ".tmp", ".temp")

@Suppress("DEPRECATION")
private fun versionOf(info: android.content.pm.PackageInfo): Long =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode else info.versionCode.toLong()

/**
 * Cihazdaki geçici dosyaları tarar. Hiçbir şey silmez; yalnızca aday listesi üretir.
 * - Sistem çöpleri: .tmp/.log/.bak vb. dosyalar, küçük resim önbellekleri, LOST.DIR
 * - Önbellek: bu uygulamanın ve (erişilebilirse) diğer uygulamaların önbellek klasörleri
 * - Kullanılmayan veriler: boş klasörler ve 0 baytlık dosyalar
 * - Gereksiz kurulum paketi: zaten yüklü olan veya bozuk APK dosyaları
 */
@Suppress("DEPRECATION")
fun scanJunk(ctx: Context, root: File, isActive: () -> Boolean): Map<JunkKind, JunkGroup> {
    val sys = ArrayList<String>(); var sysSize = 0L
    val cache = ArrayList<String>(); var cacheSize = 0L
    val unused = ArrayList<String>(); var unusedSize = 0L
    val apks = ArrayList<String>(); var apkSize = 0L

    val pm = ctx.packageManager
    val installed: Map<String, Long> = try {
        pm.getInstalledPackages(0).associate { it.packageName to versionOf(it) }
    } catch (e: Exception) {
        emptyMap()
    }

    fun addSys(f: File) { sys.add(f.path); sysSize += sizeOfTree(f) }

    val trashName = TRASH_DIR_NAME

    fun visit(dir: File, depth: Int) {
        if (!isActive() || depth > 25) return
        val children = dir.listFiles() ?: return
        if (children.isEmpty() && dir.parentFile?.path != root.path && dir != root) {
            unused.add(dir.path)
            return
        }
        for (f in children) {
            if (!isActive()) return
            val n = f.name
            if (f.isDirectory) {
                if (n == trashName) continue
                if (n in JUNK_DIRS) { addSys(f); continue }
                if (n.startsWith(".")) continue
                if ((n == "data" || n == "obb") && dir.name == "Android") continue
                visit(f, depth + 1)
            } else {
                if (n.startsWith(".thumbdata")) { addSys(f); continue }
                if (n.startsWith(".")) continue
                val ext = n.substringAfterLast('.', "").lowercase()
                val len = f.length()
                when {
                    ext in JUNK_EXT -> { sys.add(f.path); sysSize += len }
                    len == 0L -> { unused.add(f.path) }
                    ext == "apk" -> {
                        val info = try { pm.getPackageArchiveInfo(f.path, 0) } catch (e: Exception) { null }
                        val useless = if (info == null) true else {
                            val inst = installed[info.packageName]
                            inst != null && inst >= versionOf(info)
                        }
                        if (useless) { apks.add(f.path); apkSize += len }
                    }
                }
            }
        }
    }
    visit(root, 0)

    // Önbellek: kendi önbelleğimiz
    val own = ArrayList<File>()
    own.add(ctx.cacheDir)
    ctx.externalCacheDirs.filterNotNull().forEach { own.add(it) }
    val dataDir = File(root, "Android/data")
    dataDir.listFiles()?.forEach { p -> own.add(File(p, "cache")) }
    for (c in own) {
        if (!isActive()) break
        c.listFiles()?.forEach { f -> cache.add(f.path); cacheSize += sizeOfTree(f) }
    }

    return mapOf(
        JunkKind.SYSTEM to JunkGroup(sys, sysSize),
        JunkKind.CACHE to JunkGroup(cache, cacheSize),
        JunkKind.UNUSED to JunkGroup(unused, unusedSize),
        JunkKind.APKS to JunkGroup(apks, apkSize)
    )
}

/** Seçilen gruplardaki öğeleri kalıcı olarak siler; boşaltılan bayt sayısını döndürür. */
fun cleanJunk(groups: Collection<JunkGroup>, isActive: () -> Boolean): Long {
    var freed = 0L
    for (g in groups) {
        for (p in g.paths) {
            if (!isActive()) return freed
            val f = File(p)
            if (!f.exists()) continue
            val s = sizeOfTree(f)
            if (f.deleteRecursively()) freed += s
        }
    }
    return freed
}

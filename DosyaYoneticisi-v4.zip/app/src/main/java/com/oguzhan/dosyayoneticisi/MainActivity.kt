package com.oguzhan.dosyayoneticisi

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.oguzhan.dosyayoneticisi.ui.FileManagerApp

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent { FileManagerApp(vm) }
        if (savedInstanceState == null) handleLaunch(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleLaunch(intent)
    }

    /** Ana ekran kısayolundan gelen klasör/dosya yolunu açar. */
    private fun handleLaunch(i: Intent?) {
        val p = i?.getStringExtra("open_path") ?: return
        i.removeExtra("open_path")
        vm.launchPath(this, p)
    }
}

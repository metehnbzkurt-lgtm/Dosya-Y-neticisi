@file:OptIn(ExperimentalMaterial3Api::class)

package com.oguzhan.dosyayoneticisi.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oguzhan.dosyayoneticisi.MainViewModel
import com.oguzhan.dosyayoneticisi.data.openFileWith
import com.oguzhan.dosyayoneticisi.data.shareFiles
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ------------------------------------------------------------------ dahili görüntü görüntüleyici

private fun decodeForViewer(path: String, max: Int): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o)
    var s = 1
    while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
    val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
    if (bmp == null) {
        null
    } else {
        val deg = when (
            ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        ) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (deg != 0f) {
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        } else {
            bmp
        }
    }
} catch (e: Throwable) {
    null
}

@Composable
fun ImageViewerScreen(vm: MainViewModel, path: String) {
    val ctx = LocalContext.current
    val file = remember(path) { File(path) }
    var done by remember(path) { mutableStateOf(false) }
    val bmp by produceState<Bitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { decodeForViewer(path, 2400) }
        done = true
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }

    fun clamp(o: Offset, s: Float): Offset {
        val mx = box.width * (s - 1f) / 2f
        val my = box.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(file.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = {
                IconButton(onClick = { vm.pop() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") }
            },
            actions = {
                IconButton(onClick = { shareFiles(ctx, listOf(path)) }) { Icon(Icons.Filled.Share, "Paylaş") }
                IconButton(onClick = { openFileWith(ctx, file) }) {
                    Icon(Icons.AutoMirrored.Filled.OpenInNew, "Başka uygulamada aç")
                }
            },
            windowInsets = NoInsets,
            colors = barColors()
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .clipToBounds()
                .onSizeChanged { box = it }
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val ns = (scale * zoom).coerceIn(1f, 6f)
                        scale = ns
                        offset = if (ns <= 1f) Offset.Zero else clamp(offset + pan, ns)
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = {
                        if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f
                    })
                },
            contentAlignment = Alignment.Center
        ) {
            val b = bmp
            when {
                b != null -> Image(
                    bitmap = b.asImageBitmap(),
                    contentDescription = file.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offset.x,
                            translationY = offset.y
                        )
                )
                done -> Text("Görüntü açılamadı", color = Color.White)
                else -> CircularProgressIndicator(color = Color.White)
            }
        }
    }
}

// ------------------------------------------------------------------ dahili metin düzenleyici

private const val MAX_TEXT_BYTES = 1_000_000L

@Composable
fun TextEditorScreen(vm: MainViewModel, path: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val file = remember(path) { File(path) }
    var original by remember(path) { mutableStateOf<String?>(null) }
    var text by remember(path) { mutableStateOf("") }
    var error by remember(path) { mutableStateOf<String?>(null) }
    var askLeave by remember { mutableStateOf(false) }

    LaunchedEffect(path) {
        val r = withContext(Dispatchers.IO) {
            runCatching {
                if (file.length() > MAX_TEXT_BYTES) null else file.readText()
            }
        }
        val t = r.getOrNull()
        if (r.isFailure) error = "Dosya okunamadı"
        else if (t == null) error = "Dosya çok büyük (1 MB üzeri). Başka bir uygulamayla açın."
        else { original = t; text = t }
    }

    val dirty = original != null && text != original

    fun save(then: () -> Unit = {}) {
        val t = text
        scope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { file.writeText(t) }.isSuccess }
            if (ok) {
                original = t
                Toast.makeText(ctx, "Kaydedildi", Toast.LENGTH_SHORT).show()
                then()
            } else {
                Toast.makeText(ctx, "Kaydedilemedi", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun leave() { if (dirty) askLeave = true else vm.pop() }

    BackHandler(enabled = dirty) { askLeave = true }

    Column(Modifier.fillMaxSize().imePadding()) {
        TopAppBar(
            title = {
                Text(
                    file.name + if (dirty) " •" else "",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            navigationIcon = {
                IconButton(onClick = { leave() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") }
            },
            actions = {
                IconButton(onClick = { save() }, enabled = dirty) { Icon(Icons.Filled.Save, "Kaydet") }
                IconButton(onClick = { openFileWith(ctx, file) }) {
                    Icon(Icons.AutoMirrored.Filled.OpenInNew, "Başka uygulamada aç")
                }
            },
            windowInsets = NoInsets,
            colors = barColors()
        )
        val err = error
        when {
            err != null -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(err, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            original == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            else -> TextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxSize(),
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                )
            )
        }
    }

    if (askLeave) {
        AlertDialog(
            onDismissRequest = { askLeave = false },
            title = { Text("Değişiklikler kaydedilsin mi?") },
            text = { Text("Kaydedilmemiş değişiklikleriniz var.") },
            confirmButton = {
                TextButton(onClick = {
                    askLeave = false
                    save { vm.pop() }
                }) { Text("Kaydet") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { askLeave = false; vm.pop() }) { Text("Kaydetme") }
                    TextButton(onClick = { askLeave = false }) { Text("Vazgeç") }
                }
            }
        )
    }
}

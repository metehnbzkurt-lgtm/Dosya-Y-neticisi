# WorkManager, çalışanları (Worker) yansıma ile oluşturur.
-keep class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}

# Dosya Yöneticisi +

Jetpack Compose / Material 3 ile yazılmış gerçek bir Android dosya yöneticisi.

- Gerçek depolama bilgisi, kategori taraması (görüntü, video, ses, belge, arşiv, APK, yeni, büyük dosyalar)
- Klasör gezgini: kopyala, taşı, sil, yeniden adlandır, yeni klasör, paylaş, aç
- Arama, favoriler, bellek analizi, yüklü uygulamalar listesi
- Açık / koyu tema, uyarlanabilir uygulama simgesi

## v4.0 ile gelenler

- **Geri dönüşüm kutusu**: silinenler önce kutuya taşınır, geri yüklenebilir; kutu boşaltılabilir, öğeler N gün sonra otomatik silinebilir.
- **Geçici dosyalar (çöp temizleyici)**: sistem çöpleri, önbellek, kullanılmayan veriler, gereksiz kurulum paketi.
- **Ayarlar ekranı**: tema, varsayılan uygulamalar, dahili uygulamalar (görüntü görüntüleyici, metin düzenleyici),
  geri dönüşüm ayarları, "Bellek dolu" bildirimi, USB algılama, geçmiş, sistem depolaması, dosya boyutu birimi,
  gelişmiş menüler (favori, ana ekrana ekle, gizle/göster, farklı aç).
- **Geri hareketi**: Dosyalar / Ara / Favoriler sekmesinde geri hareketi uygulamayı kapatmaz, Ana Sayfa'ya döner.

Derleme: `.github/workflows/build.yml` (GitHub Actions) debug ve release (R8 ile küçültülmüş) APK üretir.
İlk açılışta "Tüm dosyalara erişim" izni istenir.

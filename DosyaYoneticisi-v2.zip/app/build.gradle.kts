plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "com.oguzhan.dosyayoneticisi"
 compileSdk = 34
 defaultConfig { applicationId = "com.oguzhan.dosyayoneticisi"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
 buildFeatures { compose = true }
 composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
 buildTypes { release { isMinifyEnabled = false } }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
dependencies {
 val bom = platform("androidx.compose:compose-bom:2024.02.00")
 implementation(bom); androidTestImplementation(bom)
 implementation("androidx.compose.material3:material3:1.2.1")
 implementation("androidx.compose.ui:ui")
 implementation("androidx.compose.ui:ui-graphics")
 implementation("androidx.compose.ui:ui-tooling-preview")
 implementation("androidx.compose.material:material-icons-extended")
 implementation("androidx.activity:activity-compose:1.8.2")
 implementation("androidx.core:core-ktx:1.12.0")
 implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
 debugImplementation("androidx.compose.ui:ui-tooling")
}
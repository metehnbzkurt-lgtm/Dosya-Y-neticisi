package com.oguzhan.dosyayoneticisi
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.oguzhan.dosyayoneticisi.ui.FileManagerScreen
import com.oguzhan.dosyayoneticisi.ui.theme.DosyaYoneticisiTheme
class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent {
   var dark by remember { mutableStateOf(false) }
   DosyaYoneticisiTheme(darkTheme = dark) {
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
     FileManagerScreen(dark = dark, onToggleDark = { dark = !dark })
    }
   }
  }
 }
}
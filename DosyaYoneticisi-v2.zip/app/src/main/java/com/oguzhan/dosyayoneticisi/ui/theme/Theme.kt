package com.oguzhan.dosyayoneticisi.ui.theme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
private val Light = lightColorScheme(primary = Color(0xFF6750A4), onPrimary = Color.White, primaryContainer = Color(0xFFEADDFF), background = Color(0xFFFEF7FF), surface = Color.White, surfaceVariant = Color(0xFFF3EDF7), onSurface = Color(0xFF1D1B20))
private val Dark = darkColorScheme(primary = Color(0xFFD0BCFF), onPrimary = Color(0xFF381E72), primaryContainer = Color(0xFF4F378B), background = Color(0xFF141218), surface = Color(0xFF1D1B20), surfaceVariant = Color(0xFF2B2930), onSurface = Color(0xFFE6E0E9))
@Composable fun DosyaYoneticisiTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
 MaterialTheme(colorScheme = if (darkTheme) Dark else Light, typography = Typography(), shapes = Shapes(extraLarge = RoundedCornerShape(28.dp), large = RoundedCornerShape(24.dp), medium = RoundedCornerShape(20.dp)), content = content)
}
# Dosya Yöneticisi + (Material 3 Expressive)

Jetpack Compose / Material 3 dosya yöneticisi arayüzü. GitHub Actions ile derlenir.
Bu zip'i reponun köküne olduğu gibi yükle; workflow zip'i açıp debug APK üretir.

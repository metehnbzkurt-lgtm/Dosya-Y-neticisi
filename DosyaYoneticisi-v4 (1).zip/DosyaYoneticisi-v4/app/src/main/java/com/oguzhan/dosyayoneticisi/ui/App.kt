@file:OptIn(ExperimentalMaterial3Api::class)

package com.oguzhan.dosyayoneticisi.ui

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.oguzhan.dosyayoneticisi.MainViewModel
import com.oguzhan.dosyayoneticisi.data.Dest
import com.oguzhan.dosyayoneticisi.data.hasAllFilesAccess
import com.oguzhan.dosyayoneticisi.ui.theme.DosyaYoneticisiTheme

@Composable
fun FileManagerApp(vm: MainViewModel = viewModel()) {
    val ctx = LocalContext.current
    val dark = vm.darkMode ?: isSystemInDarkTheme()

    // Uygulamanın kendi tema seçimine göre durum/gezinme çubuğu simgeleri
    DisposableEffect(dark) {
        (ctx as? ComponentActivity)?.enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT) { dark },
            navigationBarStyle = SystemBarStyle.auto(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT) { dark }
        )
        onDispose { }
    }

    DosyaYoneticisiTheme(darkTheme = dark, dynamicColor = vm.dynamicColor) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            var granted by remember { mutableStateOf(hasAllFilesAccess(ctx)) }
            val owner = LocalLifecycleOwner.current
            DisposableEffect(owner) {
                val obs = LifecycleEventObserver { _, e ->
                    if (e == Lifecycle.Event.ON_RESUME) granted = hasAllFilesAccess(ctx)
                }
                owner.lifecycle.addObserver(obs)
                onDispose { owner.lifecycle.removeObserver(obs) }
            }
            val legacy = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                granted = hasAllFilesAccess(ctx)
            }
            if (granted) {
                MainContent(vm)
            } else {
                PermissionScreen { requestAccess(ctx, legacy) }
            }
        }
    }
}

private fun requestAccess(ctx: Context, legacy: ManagedActivityResultLauncher<Array<String>, Map<String, Boolean>>) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            )
        } catch (e: Exception) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
    } else {
        legacy.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Filled.Folder,
            null,
            Modifier.size(72.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Text(
            "Dosyalara erişim izni gerekli",
            Modifier.padding(top = 16.dp),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Text(
            "Dosyalarınızı listeleyebilmek, kopyalayabilmek ve düzenleyebilmek için " +
                "\"Tüm dosyalara erişim\" iznini açmanız gerekir. Açılan ekranda bu uygulamanın anahtarını açıp geri dönün.",
            Modifier.padding(vertical = 12.dp),
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Button(onClick = onRequest) { Text("İzin ver") }
    }
}

@Composable
private fun MainContent(vm: MainViewModel) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { vm.onAppStart() }

    // USB bağlantısı algılama
    DisposableEffect(vm.usbDetect) {
        if (!vm.usbDetect) {
            onDispose { }
        } else {
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    vm.setUsbConnected(i.getBooleanExtra("connected", false))
                }
            }
            val sticky = ContextCompat.registerReceiver(
                ctx, receiver, IntentFilter("android.hardware.usb.action.USB_STATE"),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            vm.setUsbConnected(sticky?.getBooleanExtra("connected", false) == true)
            onDispose { ctx.unregisterReceiver(receiver) }
        }
    }

    val tabs = listOf(
        "Ana Sayfa" to Icons.Filled.Home,
        "Dosyalar" to Icons.Filled.Folder,
        "Ara" to Icons.Filled.Search,
        "Favoriler" to Icons.Filled.Favorite
    )

    // Geri hareketi: önce alt ekranlardan çık, sekmedeysen Ana Sayfa'ya dön; uygulamadan yalnızca Ana Sayfa'da çık.
    BackHandler(enabled = vm.canGoBack) { vm.goBack() }

    val d = vm.stack.last()
    val fullScreen = d is Dest.ImageView || d is Dest.TextEdit
    val showBar = !fullScreen && (vm.navAlways || vm.stack.size == 1)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.statusBars,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    tabs.forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(
                            selected = vm.currentTab == i,
                            onClick = { vm.openTab(i) },
                            icon = { Icon(icon, null) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(
            Modifier
                .padding(pad)
                .fillMaxSize()
        ) {
            key(d) {
                when (d) {
                    Dest.Home -> HomeScreen(vm)
                    is Dest.Browse -> BrowseScreen(vm, d.path)
                    is Dest.CatList -> CategoryScreen(vm, d.cat)
                    Dest.Analysis -> AnalysisScreen(vm)
                    Dest.Apps -> AppsScreen(vm)
                    Dest.Search -> SearchScreen(vm)
                    Dest.Favorites -> FavoritesScreen(vm)
                    Dest.Settings -> SettingsScreen(vm)
                    Dest.JunkCleaner -> JunkScreen(vm)
                    Dest.Trash -> TrashScreen(vm)
                    Dest.History -> HistoryScreen(vm)
                    Dest.DefaultApps -> DefaultAppsScreen(vm)
                    Dest.BuiltinApps -> BuiltinAppsScreen(vm)
                    is Dest.ImageView -> ImageViewerScreen(vm, d.path)
                    is Dest.TextEdit -> TextEditorScreen(vm, d.path)
                }
            }
        }
    }
}

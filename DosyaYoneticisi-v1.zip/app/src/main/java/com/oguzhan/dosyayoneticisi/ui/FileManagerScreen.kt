package com.oguzhan.dosyayoneticisi.ui
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
data class Category(val title: String, val subtitle: String, val icon: ImageVector, val tint: Color)
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun FileManagerScreen(dark: Boolean, onToggleDark: () -> Unit) {
 val cats = listOf(Category("Ana bellek","72,9 GB / 256 GB", Icons.Filled.Storage, Color(0xFFEADDFF)), Category("Indirilenler","252 MB (74)", Icons.Filled.Download, Color(0xFFD3E3FD)), Category("Bellek Analizi","Kullanilan 28%", Icons.Filled.PieChart, Color(0xFFC2E7FF)), Category("Goruntuler","75,9 MB (66)", Icons.Filled.Image, Color(0xFFE7D8FF)), Category("Ses","32,4 kB (1)", Icons.Filled.MusicNote, Color(0xFFD1F4D9)), Category("Videolar","170 MB (9)", Icons.Filled.Movie, Color(0xFFFFDAD6)), Category("Belgeler","26,7 MB (37)", Icons.Filled.Description, Color(0xFFCBE4FF)), Category("Uygulamalar","43,9 GB (151)", Icons.Filled.Android, Color(0xFFCCF5C6)), Category("Yeni Dosyalar","24,5 MB (27)", Icons.Filled.Schedule, Color(0xFFFFE9C6)), Category("Bulut","", Icons.Filled.Cloud, Color(0xFFD3E3FD)), Category("Uzak","", Icons.Filled.Computer, Color(0xFFE8DCCB)), Category("Agdan erisim","", Icons.Filled.Devices, Color(0xFFD8E8D8)))
 var selected by remember { mutableStateOf<Category?>(null) }
 var query by remember { mutableStateOf("") }
 var tab by remember { mutableStateOf(0) }
 Scaffold(bottomBar = { NavigationBar(containerColor = MaterialTheme.colorScheme.surface) { listOf("Ana Sayfa" to Icons.Filled.Home, "Dosyalar" to Icons.Filled.Folder, "Ara" to Icons.Filled.Search, "Favoriler" to Icons.Filled.Favorite).forEachIndexed { i, pair -> NavigationBarItem(selected = tab==i, onClick = { tab=i }, icon = { Icon(pair.second, null) }, label = { Text(pair.first) }) } } }) { pad ->
  LazyColumn(modifier = Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
   item { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) { Text("Merhaba, Oguzhan", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); IconButton(onClick = onToggleDark, modifier = Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)) { Icon(if(dark) Icons.Filled.LightMode else Icons.Filled.DarkMode, null) } } }
   item { OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("Ara: Dosyalar, klasorler...") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), singleLine = true) }
   item { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { Text("Depolama", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text("72,9 GB / 256 GB - %28 kullanildi", style = MaterialTheme.typography.bodyMedium); LinearProgressIndicator(progress = { 0.28f }, modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(99.dp))); Button(onClick = {}, shape = RoundedCornerShape(99.dp)) { Text("Temizle") } } } }
   item { Text("Kategoriler", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
   item { LazyVerticalGrid(columns = GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.height(560.dp)) { items(cats.filter { it.title.contains(query, ignoreCase = true) || query.isBlank() }) { c -> Card(onClick = { selected = c }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(28.dp), modifier = Modifier.aspectRatio(0.92f)) { Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(c.tint), contentAlignment = Alignment.Center) { Icon(c.icon, null, tint = MaterialTheme.colorScheme.primary) }; Text(c.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, maxLines = 1); Text(c.subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } } } } }
   selected?.let { c -> item { Card(shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(c.title + " - Dosyalar", fontWeight = FontWeight.Bold); Text("IMG_2026_001.jpg - 2,4 MB - Bugun"); Text("Rapor.pdf - 1,1 MB - Dun"); Text("Video_01.mp4 - 84 MB - 12 Kas"); TextButton(onClick = { selected = null }) { Text("Kapat") } } } } }
  }
 }
}
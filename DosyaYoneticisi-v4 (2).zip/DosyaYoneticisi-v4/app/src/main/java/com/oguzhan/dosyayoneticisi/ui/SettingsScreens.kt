@file:OptIn(ExperimentalMaterial3Api::class)

package com.oguzhan.dosyayoneticisi.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.oguzhan.dosyayoneticisi.MainViewModel
import com.oguzhan.dosyayoneticisi.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// ------------------------------------------------------------------ ortak parçalar

@Composable
fun SimpleBar(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    TopAppBar(
        title = { Text(title) },
        navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") }
        },
        actions = actions,
        windowInsets = NoInsets,
        colors = barColors()
    )
}

@Composable
private fun Section(text: String) {
    Text(
        text,
        Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 6.dp),
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
private fun PrefRow(title: String, subtitle: String? = null, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        if (subtitle != null) {
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun CheckRow(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    enabled: Boolean = true,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled) { onChange(!checked) }
            .padding(start = 16.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.bodyLarge,
                color = if (enabled) Color.Unspecified else MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Checkbox(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun Divide() {
    HorizontalDivider(Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)
}

@Composable
fun <T> ChoiceDialog(
    title: String,
    options: List<Pair<T, String>>,
    selected: T,
    onPick: (T) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                options.forEach { (value, label) ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(value); onDismiss() }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = value == selected, onClick = { onPick(value); onDismiss() })
                        Text(label, Modifier.padding(start = 8.dp))
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } }
    )
}

// ------------------------------------------------------------------ ayarlar

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf<String?>(null) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "-"
    }

    val themeName = when (vm.darkMode) { null -> "Varsayılan"; false -> "Açık"; true -> "Koyu" }
    val unitName = when (vm.sizeUnit) { 1 -> "KB"; 2 -> "MB"; 3 -> "GB"; else -> "Otomatik" }
    val daysName = if (vm.trashDays <= 0) "Otomatik silme kapalı" else "${vm.trashDays} gün sonra kalıcı olarak sil"
    val fullName = if (vm.fullPct <= 0) "Kapalı" else "Depolama alanı %${vm.fullPct} dolu olduğunda göster"

    Column(Modifier.fillMaxSize()) {
        SimpleBar("Ayarlar") { vm.pop() }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Section("Görünüm")
            PrefRow("Tema", themeName) { dialog = "theme" }
            CheckRow(
                "Duvar kağıdına uyumlu renkler",
                if (com.oguzhan.dosyayoneticisi.ui.theme.dynamicColorSupported)
                    "Material You: renkler duvar kağıdınıza göre ayarlanır (Android 12+)"
                else
                    "Cihazınız Android 12'den eski olduğu için kullanılamıyor",
                checked = vm.dynamicColor && com.oguzhan.dosyayoneticisi.ui.theme.dynamicColorSupported,
                enabled = com.oguzhan.dosyayoneticisi.ui.theme.dynamicColorSupported
            ) { vm.setDynamicColor(it) }
            Divide()

            Section("Genel Ayarlar")
            PrefRow("Varsayılan uygulamalar") { vm.push(Dest.DefaultApps) }
            PrefRow("Dahili uygulamalar") { vm.push(Dest.BuiltinApps) }
            Divide()

            Section("Geçici dosyalar")
            PrefRow("Geçici dosyalar", "Çöpleri tara ve temizle") { vm.push(Dest.JunkCleaner) }
            Divide()

            Section("Geri Dönüşüm Kutusu Ayarları")
            PrefRow("Geri dönüşüm kutusunu aç", "${vm.trashCount} öğe") { vm.push(Dest.Trash) }
            CheckRow("Varsayılan olarak geri dönüşüm kutusu kullan", checked = vm.useTrash) { vm.setUseTrash(it) }
            CheckRow("Geri Dönüşüm onayını göster", checked = vm.confirmTrash) { vm.setConfirmTrash(it) }
            PrefRow("Otomatik boşaltma", daysName) { dialog = "days" }
            Divide()

            Section("Bildirim ayarları")
            PrefRow("Bellek dolu", fullName) { dialog = "full" }
            Divide()

            Section("Gelişmiş Ayarlar")
            CheckRow("Alt gezinme çubuğunu her zaman göster", checked = vm.navAlways) { vm.setNavAlways(it) }
            CheckRow("USB bağlantısını algıla", checked = vm.usbDetect) { vm.setUsbDetect(it) }
            CheckRow("Geçmiş göster", checked = vm.showHistory) { vm.setShowHistory(it) }
            CheckRow("Sistem depolamasını göster", checked = vm.showSystem) { vm.setShowSystem(it) }
            PrefRow("Dosya boyutu birimi", unitName) { dialog = "unit" }
            Divide()

            Section("Gelişmiş menüleri göster")
            CheckRow("Favorilere ekle (yer imi)", checked = vm.menuBookmark) { vm.setMenuBookmark(it) }
            CheckRow("Ana Ekrana ekle", checked = vm.menuHome) { vm.setMenuHome(it) }
            CheckRow("Gizle/Gizleme", checked = vm.menuHide) { vm.setMenuHide(it) }
            CheckRow("Farklı aç", checked = vm.menuOpenWith) { vm.setMenuOpenWith(it) }
            Divide()

            Section("Hakkında")
            PrefRow("Hakkında", "Sürüm $version") { }
            Spacer(Modifier.height(24.dp))
        }
    }

    when (dialog) {
        "theme" -> ChoiceDialog(
            "Tema",
            listOf(-1 to "Varsayılan (sistem)", 0 to "Açık", 1 to "Koyu"),
            when (vm.darkMode) { null -> -1; false -> 0; true -> 1 },
            { vm.setDarkMode(when (it) { 0 -> false; 1 -> true; else -> null }) },
            { dialog = null }
        )
        "days" -> ChoiceDialog(
            "Otomatik boşaltma",
            listOf(0 to "Hiçbir zaman", 7 to "7 gün sonra", 30 to "30 gün sonra", 60 to "60 gün sonra"),
            vm.trashDays,
            { vm.setTrashDays(it) },
            { dialog = null }
        )
        "full" -> ChoiceDialog(
            "Bellek dolu bildirimi",
            listOf(0 to "Kapalı", 85 to "%85 dolu olduğunda", 90 to "%90 dolu olduğunda",
                95 to "%95 dolu olduğunda", 98 to "%98 dolu olduğunda"),
            vm.fullPct,
            {
                vm.setFullPct(it)
                if (it > 0 && Build.VERSION.SDK_INT >= 33 &&
                    ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                    android.content.pm.PackageManager.PERMISSION_GRANTED
                ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            },
            { dialog = null }
        )
        "unit" -> ChoiceDialog(
            "Dosya boyutu birimi",
            listOf(0 to "Otomatik", 1 to "KB", 2 to "MB", 3 to "GB"),
            vm.sizeUnit,
            { vm.setSizeUnit(it) },
            { dialog = null }
        )
    }
}

// ------------------------------------------------------------------ varsayılan uygulamalar

private fun builtinEnabled(vm: MainViewModel, k: AppKind): Boolean = when (k) {
    AppKind.IMAGE -> vm.builtinImage
    AppKind.TEXT -> vm.builtinText
    else -> false
}

@Composable
fun DefaultAppsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var pick by remember { mutableStateOf<AppKind?>(null) }

    fun summary(k: AppKind): String {
        val c = vm.defaultApps[k.name]
        return when {
            c == null -> if (builtinEnabled(vm, k)) "Dahili uygulama" else "Sistem varsayılanı"
            c == CHOICE_ASK -> "Her seferinde sor"
            c == CHOICE_BUILTIN -> "Dahili uygulama"
            else -> runCatching {
                val pm = ctx.packageManager
                pm.getApplicationLabel(pm.getApplicationInfo(c, 0)).toString()
            }.getOrDefault(c)
        }
    }

    Column(Modifier.fillMaxSize()) {
        SimpleBar("Varsayılan uygulamalar") { vm.pop() }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Text(
                "Dosyalar uygulama içinden açılırken hangi uygulamanın kullanılacağını seçin.",
                Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            AppKind.values().forEach { k -> PrefRow(k.title, summary(k)) { pick = k } }
        }
    }

    val k = pick
    if (k != null) {
        val apps = remember(k) { resolversFor(ctx, k) }
        val options = buildList<Pair<String, String>> {
            add("" to "Sistem varsayılanı")
            add(CHOICE_ASK to "Her seferinde sor")
            if (builtinEnabled(vm, k)) add(CHOICE_BUILTIN to "Dahili uygulama")
            addAll(apps)
        }
        ChoiceDialog(
            k.title,
            options,
            vm.defaultApps[k.name] ?: "",
            { vm.setDefaultApp(k, if (it.isEmpty()) null else it) },
            { pick = null }
        )
    }
}

@Composable
fun BuiltinAppsScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize()) {
        SimpleBar("Dahili uygulamalar") { vm.pop() }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            CheckRow(
                "Görüntü görüntüleyici",
                "Resimleri uygulama içinde açar; iki parmakla yakınlaştırılır",
                vm.builtinImage
            ) { vm.setBuiltinImage(it) }
            CheckRow(
                "Metin düzenleyici",
                "txt, md, csv, json, xml gibi dosyaları uygulama içinde açar ve düzenlemeye izin verir",
                vm.builtinText
            ) { vm.setBuiltinText(it) }
        }
    }
}

// ------------------------------------------------------------------ geçmiş

@Composable
fun HistoryScreen(vm: MainViewModel) {
    var items by remember { mutableStateOf<List<FileItem>?>(null) }
    LaunchedEffect(vm.history, vm.refreshTick) {
        val h = vm.history
        items = withContext(Dispatchers.IO) {
            h.map { File(it) }.filter { it.exists() }.map { toItem(it) }
        }
    }
    FileScreen(
        vm = vm,
        title = "Geçmiş",
        items = items,
        emptyText = "Henüz açılmış dosya yok",
        onBack = { vm.pop() },
        showParent = true,
        topActions = {
            IconButton(onClick = { vm.clearHistory() }) { Icon(Icons.Filled.DeleteSweep, "Geçmişi temizle") }
        }
    )
}

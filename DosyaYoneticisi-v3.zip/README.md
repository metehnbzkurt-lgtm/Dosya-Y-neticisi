# Dosya Yöneticisi +

Jetpack Compose / Material 3 ile yazılmış gerçek bir Android dosya yöneticisi.

- Gerçek depolama bilgisi, kategori taraması (görüntü, video, ses, belge, arşiv, APK, yeni, büyük dosyalar)
- Klasör gezgini: kopyala, taşı, sil, yeniden adlandır, yeni klasör, paylaş, aç
- Arama, favoriler, bellek analizi, yüklü uygulamalar listesi
- Açık / koyu tema, uyarlanabilir uygulama simgesi

Derleme: `.github/workflows/build.yml` (GitHub Actions) debug ve release (R8 ile küçültülmüş) APK üretir.
İlk açılışta "Tüm dosyalara erişim" izni istenir.

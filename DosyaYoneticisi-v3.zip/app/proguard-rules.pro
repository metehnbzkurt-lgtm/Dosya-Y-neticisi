# Uygulama yansıma (reflection) kullanmadığı için özel kural gerekmez.

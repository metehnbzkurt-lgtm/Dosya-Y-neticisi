@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.oguzhan.dosyayoneticisi.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.oguzhan.dosyayoneticisi.MainViewModel
import com.oguzhan.dosyayoneticisi.data.Clip
import com.oguzhan.dosyayoneticisi.data.Dest
import com.oguzhan.dosyayoneticisi.data.FileItem
import com.oguzhan.dosyayoneticisi.data.SortBy
import com.oguzhan.dosyayoneticisi.data.openFile
import com.oguzhan.dosyayoneticisi.data.shareFiles
import java.io.File

private fun toggle(set: Set<String>, p: String): Set<String> = if (p in set) set - p else set + p

@Composable
private fun BarAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = MaterialTheme.colorScheme.onSecondaryContainer)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
    }
}

@Composable
fun SortMenu(vm: MainViewModel) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Filled.Sort, "Sırala") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            listOf(
                SortBy.NAME to "Ada göre",
                SortBy.DATE to "Tarihe göre",
                SortBy.SIZE to "Boyuta göre"
            ).forEach { (s, label) ->
                DropdownMenuItem(
                    text = { Text(label + if (vm.sortBy == s) "  ✓" else "") },
                    onClick = { vm.setSort(s); open = false }
                )
            }
            DropdownMenuItem(
                text = { Text(if (vm.sortAsc) "Azalan sırala" else "Artan sırala") },
                onClick = { vm.toggleSortOrder(); open = false }
            )
            DropdownMenuItem(
                text = { Text(if (vm.showHidden) "Gizli dosyaları gizle" else "Gizli dosyaları göster") },
                onClick = { vm.toggleHidden(); open = false }
            )
        }
    }
}

/**
 * Tüm dosya listelerinin ortak ekranı: üst çubuk, seçim modu, kopyala/taşı/sil/paylaş,
 * yeniden adlandırma ve yapıştırma çubuğu burada.
 */
@Composable
fun FileScreen(
    vm: MainViewModel,
    title: String,
    items: List<FileItem>?,
    emptyText: String,
    onBack: (() -> Unit)?,
    pasteDir: String? = null,
    showParent: Boolean = false,
    topActions: @Composable RowScope.() -> Unit = {},
    belowBar: @Composable () -> Unit = {}
) {
    val ctx = LocalContext.current
    var selected by remember { mutableStateOf(setOf<String>()) }
    var showDelete by remember { mutableStateOf(false) }
    var renamePath by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    val selecting = selected.isNotEmpty()

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    BackHandler(enabled = selecting) { selected = emptySet() }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (selecting) {
                TopAppBar(
                    title = { Text("${selected.size} seçili") },
                    navigationIcon = {
                        IconButton(onClick = { selected = emptySet() }) { Icon(Icons.Filled.Close, "Seçimi kapat") }
                    },
                    actions = {
                        IconButton(onClick = { selected = items.orEmpty().map { it.path }.toSet() }) {
                            Icon(Icons.Filled.SelectAll, "Tümünü seç")
                        }
                    },
                    windowInsets = NoInsets,
                    colors = barColors()
                )
            } else {
                TopAppBar(
                    title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = {
                        if (onBack != null) {
                            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") }
                        }
                    },
                    actions = topActions,
                    windowInsets = NoInsets,
                    colors = barColors()
                )
            }
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            belowBar()

            when {
                items == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                items.isEmpty() -> Box(
                    Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        emptyText,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
                else -> LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    items(items, key = { it.path }) { item ->
                        FileRow(
                            item = item,
                            selected = item.path in selected,
                            favorite = item.path in vm.favorites,
                            showParent = showParent,
                            onClick = {
                                if (selecting) selected = toggle(selected, item.path)
                                else if (item.isDir) vm.push(Dest.Browse(item.path))
                                else openFile(ctx, File(item.path))
                            },
                            onLongClick = { selected = toggle(selected, item.path) }
                        )
                    }
                }
            }
        }

        if (selecting) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(12.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                tonalElevation = 6.dp,
                shadowElevation = 6.dp
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    BarAction(Icons.Filled.ContentCopy, "Kopyala") {
                        vm.clipboard = Clip(selected.toList(), false)
                        toast("${selected.size} öğe kopyalandı. Bir klasörde Yapıştır'a dokunun")
                        selected = emptySet()
                    }
                    BarAction(Icons.Filled.ContentCut, "Taşı") {
                        vm.clipboard = Clip(selected.toList(), true)
                        toast("${selected.size} öğe seçildi. Bir klasörde Yapıştır'a dokunun")
                        selected = emptySet()
                    }
                    BarAction(Icons.Filled.Share, "Paylaş") { shareFiles(ctx, selected.toList()) }
                    BarAction(Icons.Filled.Delete, "Sil") { showDelete = true }
                    Box {
                        BarAction(Icons.Filled.MoreVert, "Diğer") { menuOpen = true }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            if (selected.size == 1) {
                                DropdownMenuItem(
                                    text = { Text("Yeniden adlandır") },
                                    onClick = { renamePath = selected.first(); menuOpen = false }
                                )
                            }
                            val allFav = selected.all { it in vm.favorites }
                            DropdownMenuItem(
                                text = { Text(if (allFav) "Favorilerden çıkar" else "Favorilere ekle") },
                                onClick = {
                                    vm.toggleFavorites(selected.toList())
                                    menuOpen = false
                                    selected = emptySet()
                                }
                            )
                        }
                    }
                }
            }
        } else {
            val clip = vm.clipboard
            if (clip != null && pasteDir != null) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(12.dp)
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    tonalElevation = 6.dp,
                    shadowElevation = 6.dp
                ) {
                    Row(
                        Modifier.padding(start = 20.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${clip.paths.size} öğe • ${if (clip.cut) "Taşı" else "Kopyala"}",
                            Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        TextButton(onClick = { vm.paste(pasteDir) { toast(it) } }) { Text("Yapıştır") }
                        IconButton(onClick = { vm.clipboard = null }) { Icon(Icons.Filled.Close, "İptal") }
                    }
                }
            }
        }
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Silinsin mi?") },
            text = { Text("${selected.size} öğe kalıcı olarak silinecek.") },
            confirmButton = {
                TextButton(onClick = {
                    val paths = selected.toList()
                    showDelete = false
                    selected = emptySet()
                    vm.delete(paths) { toast(it) }
                }) { Text("Sil") }
            },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Vazgeç") } }
        )
    }

    val rp = renamePath
    if (rp != null) {
        TextInputDialog(
            title = "Yeniden adlandır",
            initial = File(rp).name,
            confirmLabel = "Tamam",
            onDismiss = { renamePath = null },
            onConfirm = { name ->
                renamePath = null
                selected = emptySet()
                vm.rename(rp, name) { toast(it) }
            }
        )
    }
}

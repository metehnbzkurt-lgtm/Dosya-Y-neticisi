package com.oguzhan.dosyayoneticisi.data

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.nio.file.FileVisitOption
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes
import java.util.EnumSet

const val LARGE_BYTES = 100L * 1024 * 1024
const val WEEK_MS = 7L * 24 * 60 * 60 * 1000

private val IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")
private val VID = setOf("mp4", "mkv", "avi", "mov", "3gp", "webm", "m4v", "wmv", "flv")
private val AUD = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "amr", "wma")
private val DOC = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "odt", "ods", "csv", "epub", "md")
private val ARC = setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz")

fun typeOf(name: String): Cat? {
    val dot = name.lastIndexOf('.')
    if (dot < 0 || dot == name.length - 1) return null
    val e = name.substring(dot + 1).lowercase()
    return when {
        e in IMG -> Cat.IMAGES
        e in VID -> Cat.VIDEO
        e in AUD -> Cat.AUDIO
        e in DOC -> Cat.DOCS
        e in ARC -> Cat.ARCHIVES
        e == "apk" -> Cat.APK
        else -> null
    }
}

// ---------------------------------------------------------------- depolama

fun readStorage(root: File): StorageInfo = try {
    val s = StatFs(root.path)
    val total = s.totalBytes
    StorageInfo(total, total - s.availableBytes)
} catch (e: Exception) {
    StorageInfo(0L, 0L)
}

// ---------------------------------------------------------------- tarama

fun walkFiles(
    root: File,
    isActive: () -> Boolean,
    onDir: ((Path) -> Unit)? = null,
    onFile: (path: Path, name: String, size: Long, modified: Long) -> Unit
) {
    val rootPath = root.toPath()
    try {
        Files.walkFileTree(
            rootPath,
            EnumSet.of(FileVisitOption.FOLLOW_LINKS),
            Int.MAX_VALUE,
            object : SimpleFileVisitor<Path>() {
                override fun preVisitDirectory(dir: Path, attrs: BasicFileAttributes): FileVisitResult {
                    if (!isActive()) return FileVisitResult.TERMINATE
                    if (dir != rootPath) {
                        val n = dir.fileName?.toString().orEmpty()
                        if (n.startsWith(".")) return FileVisitResult.SKIP_SUBTREE
                        if ((n == "data" || n == "obb") && dir.parent?.fileName?.toString() == "Android") {
                            return FileVisitResult.SKIP_SUBTREE
                        }
                        onDir?.invoke(dir)
                    }
                    return FileVisitResult.CONTINUE
                }

                override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                    if (!isActive()) return FileVisitResult.TERMINATE
                    if (attrs.isRegularFile) {
                        val n = file.fileName?.toString().orEmpty()
                        if (!n.startsWith(".")) {
                            onFile(file, n, attrs.size(), attrs.lastModifiedTime().toMillis())
                        }
                    }
                    return FileVisitResult.CONTINUE
                }

                override fun visitFileFailed(file: Path, exc: IOException): FileVisitResult =
                    FileVisitResult.CONTINUE
            }
        )
    } catch (e: Exception) {
        // erişilemeyen alanlar sessizce atlanır
    }
}

fun scanStorage(root: File, isActive: () -> Boolean): ScanResult {
    val n = Cat.values().size
    val counts = IntArray(n)
    val sizes = LongArray(n)
    var total = 0L
    var files = 0
    val weekAgo = System.currentTimeMillis() - WEEK_MS
    val dl = File(root, Environment.DIRECTORY_DOWNLOADS).path + "/"

    walkFiles(root, isActive) { path, name, size, mod ->
        total += size
        files++
        val t = typeOf(name)
        if (t != null) {
            counts[t.ordinal]++
            sizes[t.ordinal] += size
        }
        if (path.toString().startsWith(dl)) {
            counts[Cat.DOWNLOADS.ordinal]++
            sizes[Cat.DOWNLOADS.ordinal] += size
        }
        if (mod >= weekAgo) {
            counts[Cat.NEW.ordinal]++
            sizes[Cat.NEW.ordinal] += size
        }
        if (size >= LARGE_BYTES) {
            counts[Cat.LARGE.ordinal]++
            sizes[Cat.LARGE.ordinal] += size
        }
    }
    val map = Cat.values().associateWith { CatStat(counts[it.ordinal], sizes[it.ordinal]) }
    return ScanResult(map, total, files)
}

// ---------------------------------------------------------------- listeleme

fun toItem(f: File): FileItem {
    val dir = f.isDirectory
    return FileItem(
        path = f.path,
        name = f.name,
        isDir = dir,
        size = if (dir) 0L else f.length(),
        modified = f.lastModified(),
        childCount = if (dir) (f.list()?.size ?: 0) else -1
    )
}

private val dirsFirst = Comparator<FileItem> { a, b ->
    if (a.isDir == b.isDir) 0 else if (a.isDir) -1 else 1
}

fun listDir(dir: File, sort: SortBy, asc: Boolean, hidden: Boolean): List<FileItem> {
    val files = dir.listFiles() ?: return emptyList()
    val list = ArrayList<FileItem>(files.size)
    for (f in files) {
        if (!hidden && f.name.startsWith(".")) continue
        list.add(toItem(f))
    }
    val base: Comparator<FileItem> = when (sort) {
        SortBy.NAME -> Comparator<FileItem> { a, b -> a.name.compareTo(b.name, ignoreCase = true) }
        SortBy.DATE -> Comparator<FileItem> { a, b -> a.modified.compareTo(b.modified) }
        SortBy.SIZE -> Comparator<FileItem> { a, b -> a.size.compareTo(b.size) }
    }
    val ordered: Comparator<FileItem> = if (asc) base else base.reversed()
    return list.sortedWith(dirsFirst.then(ordered))
}

fun listCategory(root: File, cat: Cat, isActive: () -> Boolean): List<FileItem> {
    val out = ArrayList<FileItem>()
    val weekAgo = System.currentTimeMillis() - WEEK_MS
    walkFiles(root, isActive) { path, name, size, mod ->
        val keep = when (cat) {
            Cat.NEW -> mod >= weekAgo
            Cat.LARGE -> size >= LARGE_BYTES
            else -> typeOf(name) == cat
        }
        if (keep) out.add(FileItem(path.toString(), name, false, size, mod))
    }
    val sorted = if (cat == Cat.LARGE) out.sortedByDescending { it.size } else out.sortedByDescending { it.modified }
    return if (sorted.size > 3000) sorted.subList(0, 3000) else sorted
}

fun searchFiles(root: File, q: String, limit: Int, isActive: () -> Boolean): List<FileItem> {
    val out = ArrayList<FileItem>()
    val active = { isActive() && out.size < limit }
    walkFiles(
        root,
        active,
        onDir = { d ->
            val n = d.fileName?.toString().orEmpty()
            if (n.contains(q, ignoreCase = true)) out.add(toItem(d.toFile()))
        }
    ) { path, name, size, mod ->
        if (name.contains(q, ignoreCase = true)) out.add(FileItem(path.toString(), name, false, size, mod))
    }
    return out.sortedWith(dirsFirst.then(Comparator<FileItem> { a, b -> a.name.compareTo(b.name, ignoreCase = true) }))
}

// ---------------------------------------------------------------- işlemler

fun uniqueTarget(dir: File, name: String): File {
    var t = File(dir, name)
    if (!t.exists()) return t
    val dot = name.lastIndexOf('.')
    val base = if (dot > 0) name.substring(0, dot) else name
    val ext = if (dot > 0) name.substring(dot) else ""
    var i = 1
    while (t.exists()) {
        t = File(dir, "$base ($i)$ext")
        i++
    }
    return t
}

fun copyItem(src: File, target: File) {
    if (src.isDirectory) src.copyRecursively(target, overwrite = false)
    else src.copyTo(target, overwrite = false)
}

fun moveItem(src: File, target: File) {
    if (!src.renameTo(target)) {
        copyItem(src, target)
        src.deleteRecursively()
    }
}

fun isInside(dir: File, src: File): Boolean =
    dir.path == src.path || dir.path.startsWith(src.path + "/")

// ---------------------------------------------------------------- uygulamalar

@Suppress("DEPRECATION")
fun queryApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    return pm.getInstalledApplications(0)
        .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
        .map { AppInfo(pm.getApplicationLabel(it).toString(), it.packageName, File(it.sourceDir).length()) }
        .sortedBy { it.label.lowercase() }
}

fun openAppSettings(ctx: Context, pkg: String) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Uygulama ayarları açılamadı", Toast.LENGTH_SHORT).show()
    }
}

// ---------------------------------------------------------------- aç / paylaş

fun mimeOf(name: String): String {
    val ext = name.substringAfterLast('.', "").lowercase()
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
}

private fun uriFor(ctx: Context, f: File): Uri =
    FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)

fun openFile(ctx: Context, f: File) {
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uriFor(ctx, f), mimeOf(f.name))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "Bu dosyayı açacak bir uygulama yok", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "Dosya açılamadı", Toast.LENGTH_SHORT).show()
    }
}

fun shareFiles(ctx: Context, paths: List<String>) {
    val files = paths.map { File(it) }.filter { it.isFile }
    if (files.isEmpty()) {
        Toast.makeText(ctx, "Klasörler paylaşılamaz", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val uris = ArrayList(files.map { uriFor(ctx, it) })
        val i = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND)
                .setType(mimeOf(files[0].name))
                .putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE)
                .setType("*/*")
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Paylaş"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Paylaşılamadı", Toast.LENGTH_SHORT).show()
    }
}

// ---------------------------------------------------------------- izin

fun hasAllFilesAccess(ctx: Context): Boolean =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        ctx.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED &&
            ctx.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
    }

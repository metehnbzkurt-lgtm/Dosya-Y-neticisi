package com.oguzhan.dosyayoneticisi

import android.app.Application
import android.content.Context
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.oguzhan.dosyayoneticisi.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    val root: File = Environment.getExternalStorageDirectory()

    // ---- gezinme
    var stack by mutableStateOf<List<Dest>>(listOf(Dest.Home))
        private set

    val currentTab: Int
        get() = when (stack.first()) {
            Dest.Home -> 0
            is Dest.Browse -> 1
            Dest.Search -> 2
            Dest.Favorites -> 3
            else -> 0
        }

    fun push(d: Dest) { stack = stack + d }

    fun pop() { if (stack.size > 1) stack = stack.dropLast(1) }

    fun openTab(i: Int) {
        stack = listOf(
            when (i) {
                1 -> Dest.Browse(root.path)
                2 -> Dest.Search
                3 -> Dest.Favorites
                else -> Dest.Home
            }
        )
    }

    fun goTo(path: String) {
        val idx = stack.indexOfLast { it == Dest.Browse(path) }
        stack = if (idx >= 0) stack.take(idx + 1) else stack + Dest.Browse(path)
    }

    // ---- ayarlar
    var darkMode by mutableStateOf<Boolean?>(
        when (prefs.getInt("dark", -1)) { 0 -> false; 1 -> true; else -> null }
    )
        private set

    fun toggleDark(currentlyDark: Boolean) {
        val n = !currentlyDark
        darkMode = n
        prefs.edit().putInt("dark", if (n) 1 else 0).apply()
    }

    var sortBy by mutableStateOf(
        runCatching { SortBy.valueOf(prefs.getString("sort", "NAME") ?: "NAME") }.getOrDefault(SortBy.NAME)
    )
        private set
    var sortAsc by mutableStateOf(prefs.getBoolean("asc", true))
        private set
    var showHidden by mutableStateOf(prefs.getBoolean("hidden", false))
        private set

    fun setSort(s: SortBy) { sortBy = s; prefs.edit().putString("sort", s.name).apply() }
    fun toggleSortOrder() { sortAsc = !sortAsc; prefs.edit().putBoolean("asc", sortAsc).apply() }
    fun toggleHidden() { showHidden = !showHidden; prefs.edit().putBoolean("hidden", showHidden).apply() }

    // ---- favoriler
    var favorites by mutableStateOf<Set<String>>(prefs.getStringSet("fav", emptySet())?.toSet() ?: emptySet())
        private set

    fun toggleFavorites(paths: List<String>) {
        val allFav = paths.all { it in favorites }
        favorites = if (allFav) favorites - paths.toSet() else favorites + paths
        prefs.edit().putStringSet("fav", favorites).apply()
    }

    // ---- depolama / tarama
    var storage by mutableStateOf(readStorage(root))
        private set
    var stats by mutableStateOf<ScanResult?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    var apps by mutableStateOf<List<AppInfo>?>(null)
        private set
    var refreshTick by mutableIntStateOf(0)
        private set

    private var scanJob: Job? = null

    fun refreshStorage() { storage = readStorage(root) }

    fun refreshStats() {
        scanJob?.cancel()
        scanning = true
        scanJob = viewModelScope.launch {
            val job = coroutineContext[Job]
            val r = withContext(Dispatchers.IO) { scanStorage(root) { job?.isActive != false } }
            stats = r
            storage = readStorage(root)
            scanning = false
        }
    }

    fun loadApps() {
        viewModelScope.launch {
            apps = withContext(Dispatchers.IO) { queryApps(getApplication()) }
        }
    }

    private fun afterChange() {
        refreshTick++
        storage = readStorage(root)
        refreshStats()
    }

    // ---- arama
    var searchQuery by mutableStateOf("")

    // ---- pano ve dosya işlemleri
    var clipboard by mutableStateOf<Clip?>(null)
    var busy by mutableStateOf(false)
        private set

    fun delete(paths: List<String>, done: (String) -> Unit) {
        viewModelScope.launch {
            busy = true
            val ok = withContext(Dispatchers.IO) { paths.count { File(it).deleteRecursively() } }
            busy = false
            if (favorites.any { it in paths }) {
                favorites = favorites - paths.toSet()
                prefs.edit().putStringSet("fav", favorites).apply()
            }
            afterChange()
            done("$ok öğe silindi")
        }
    }

    fun paste(dir: String, done: (String) -> Unit) {
        val c = clipboard ?: return
        viewModelScope.launch {
            busy = true
            val ok = withContext(Dispatchers.IO) {
                var n = 0
                val dest = File(dir)
                for (p in c.paths) {
                    val src = File(p)
                    if (!src.exists()) continue
                    if (src.isDirectory && isInside(dest, src)) continue
                    if (c.cut && src.parentFile?.path == dir) continue
                    try {
                        val target = uniqueTarget(dest, src.name)
                        if (c.cut) moveItem(src, target) else copyItem(src, target)
                        n++
                    } catch (e: Exception) {
                        // bu öğe atlanır
                    }
                }
                n
            }
            busy = false
            if (c.cut) clipboard = null
            afterChange()
            done("$ok öğe ${if (c.cut) "taşındı" else "kopyalandı"}")
        }
    }

    fun rename(path: String, newName: String, done: (String) -> Unit) {
        val name = newName.trim()
        if (name.isEmpty() || name.contains('/')) {
            done("Geçersiz ad")
            return
        }
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                val f = File(path)
                val t = File(f.parentFile, name)
                !t.exists() && f.renameTo(t)
            }
            afterChange()
            done(if (ok) "Yeniden adlandırıldı" else "Bu adda bir öğe var veya işlem başarısız")
        }
    }

    fun newFolder(parent: String, name: String, done: (String) -> Unit) {
        val n = name.trim()
        if (n.isEmpty() || n.contains('/')) {
            done("Geçersiz ad")
            return
        }
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                val t = File(parent, n)
                !t.exists() && t.mkdirs()
            }
            afterChange()
            done(if (ok) "Klasör oluşturuldu" else "Klasör oluşturulamadı")
        }
    }
}
